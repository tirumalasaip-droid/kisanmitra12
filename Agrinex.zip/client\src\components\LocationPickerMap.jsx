import React, { useEffect, useRef } from 'react';
import L from 'leaflet';

export default function LocationPickerMap({ lat, lng, onSelectLocation, height = '260px' }) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markerRef = useRef(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    const initialLat = lat || 16.3067;
    const initialLng = lng || 80.4365;

    // Create Leaflet map instance
    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLng],
      zoom: 11,
      scrollWheelZoom: true,
    });
    mapInstanceRef.current = map;

    // OpenStreetMap standard tiles (free, open-source mapping)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Initial marker
    const marker = L.marker([initialLat, initialLng], {
      draggable: true
    }).addTo(map);
    markerRef.current = marker;

    // Drag end listener
    marker.on('dragend', function (event) {
      const position = event.target.getLatLng();
      onSelectLocation(position.lat, position.lng);
    });

    // Map click listener to relocate pin
    map.on('click', function (e) {
      marker.setLatLng(e.latlng);
      onSelectLocation(e.latlng.lat, e.latlng.lng);
    });

    return () => {
      map.remove();
    };
  }, []);

  // Sync marker position if lat/lng changed externally (e.g. from GPS button)
  useEffect(() => {
    if (mapInstanceRef.current && markerRef.current && lat && lng) {
      markerRef.current.setLatLng([lat, lng]);
      mapInstanceRef.current.setView([lat, lng], 13);
    }
  }, [lat, lng]);

  return (
    <div className="map-picker-container" style={{ width: '100%', borderRadius: '12px', overflow: 'hidden', border: '1px solid #d1d5db' }}>
      <div ref={mapContainerRef} style={{ height: height, width: '100%' }} />
      <div style={{ padding: '8px 12px', background: '#f8fafc', fontSize: '12px', color: '#64748b', display: 'flex', justifyContent: 'space-between' }}>
        <span>📍 Click or drag pin to select farm location</span>
        <span>Lat: {lat?.toFixed(4)}, Lng: {lng?.toFixed(4)}</span>
      </div>
    </div>
  );
}
