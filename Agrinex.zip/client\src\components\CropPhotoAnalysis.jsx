import React, { useState } from 'react';
import { TRANSLATIONS, COMMON_CROPS } from '../translations';
import { Camera, Upload, AlertTriangle, ShieldAlert, Sparkles, CheckCircle2, HelpCircle } from 'lucide-react';

export default function CropPhotoAnalysis({ profile }) {
  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;

  const [selectedImage, setSelectedImage] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [diagnosisResult, setDiagnosisResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Handle image selection
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (JPG, PNG, WebP).');
      return;
    }

    setErrorMsg('');
    setDiagnosisResult(null);

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result);
      setPreviewUrl(reader.result);
    };
    reader.readAsDataURL(file);
  };

  // Run AI Vision Diagnosis
  const handleAnalyzePhoto = async () => {
    if (!selectedImage) {
      setErrorMsg(t.noImageSelected);
      return;
    }

    setAnalyzing(true);
    setErrorMsg('');
    setDiagnosisResult(null);

    try {
      const cropObj = COMMON_CROPS.find(c => c.id === profile.crop);
      const cropDisplayName = cropObj ? (cropObj[profile.language] || cropObj.en) : profile.crop;

      const res = await fetch('/api/ai/analyze-crop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: selectedImage,
          mimeType: 'image/jpeg',
          language: profile.language,
          farmerName: profile.name,
          crop: cropDisplayName,
          stage: profile.cropStage,
          locationName: profile.locationName
        })
      });

      const data = await res.json();

      if (!res.ok) {
        if (data.error === 'AI_VISION_NOT_CONFIGURED') {
          setErrorMsg(
            profile.language === 'te'
              ? 'నెక్స్ AI విజన్ సదుపాయం కోసం backend/.env లో చెల్లుబాటు అయ్యే GEMINI_API_KEY అవసరం. దయచేసి aistudio.google.com నుండి ఉచిత కీని పొందండి.'
              : profile.language === 'hi'
              ? 'फसल फोटो विश्लेषण के लिए backend/.env में GEMINI_API_KEY आवश्यक है। कृपया https://aistudio.google.com/ से मुफ्त कुंजी प्राप्त करें।'
              : data.message || 'An AI vision service must be configured before crop photo diagnosis can work.'
          );
        } else {
          setErrorMsg(data.message || 'Failed to analyze crop photo.');
        }
      } else {
        setDiagnosisResult(data.analysis);
      }
    } catch (err) {
      console.error('Vision analysis request failed:', err);
      setErrorMsg('Network error: Could not connect to analysis service.');
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="crop-vision-container">
      <div className="vision-header">
        <div className="vision-title-group">
          <Camera size={26} color="#16a34a" />
          <div>
            <h2 className="title-text">{t.visionTitle}</h2>
            <p className="subtitle-text">{t.visionSubtitle}</p>
          </div>
        </div>
      </div>

      {/* Safety & Protocol Banner */}
      <div className="vision-disclaimer-box">
        <ShieldAlert size={20} color="#b45309" />
        <p>{t.visionDisclaimer}</p>
      </div>

      {/* Upload & Preview Section */}
      <div className="upload-box-wrapper">
        <label className="image-dropzone">
          <input 
            type="file" 
            accept="image/*" 
            capture="environment" 
            onChange={handleImageChange}
            className="hidden-file-input"
          />
          {previewUrl ? (
            <div className="preview-container">
              <img src={previewUrl} alt="Crop sample" className="preview-img" />
              <div className="change-overlay">
                <Camera size={20} />
                <span>{profile.language === 'te' ? 'మరొక ఫోటో ఎంచుకోండి' : profile.language === 'hi' ? 'दूसरी फोटो बदलें' : 'Change Photo'}</span>
              </div>
            </div>
          ) : (
            <div className="placeholder-zone">
              <div className="icon-circle">
                <Upload size={32} color="#16a34a" />
              </div>
              <div className="zone-text-primary">{t.uploadPrompt}</div>
              <div className="zone-text-secondary">Leaf, stem, fruit, or pest damage (JPG, PNG)</div>
            </div>
          )}
        </label>

        {previewUrl && (
          <div className="analyze-action-bar">
            <button
              type="button"
              className="btn-primary-large"
              onClick={handleAnalyzePhoto}
              disabled={analyzing}
            >
              <Sparkles size={20} />
              <span>{analyzing ? t.analyzingImage : (profile.language === 'te' ? 'పంటను పరిశీలించి వ్యాధి గుర్తించండి' : profile.language === 'hi' ? 'फोटो का विश्लेषण करें' : 'Diagnose Crop Symptoms')}</span>
            </button>
          </div>
        )}
      </div>

      {/* Error / Not Configured Notice */}
      {errorMsg && (
        <div className="vision-error-card">
          <AlertTriangle size={22} color="#dc2626" />
          <div className="error-body">
            <strong>{profile.language === 'te' ? 'విశ్లేషణ గమనిక:' : profile.language === 'hi' ? 'विश्लेषण सूचना:' : 'Diagnosis Notice:'}</strong>
            <p>{errorMsg}</p>
          </div>
        </div>
      )}

      {/* Diagnosis Results Display */}
      {diagnosisResult && (
        <div className="diagnosis-results-card">
          <div className="results-header">
            <CheckCircle2 size={24} color="#15803d" />
            <div>
              <h3>{profile.language === 'te' ? 'నెక్స్ AI పంట పరిశీలన నివేదిక' : profile.language === 'hi' ? 'नेक्स AI फसल जांच रिपोर्ट' : 'Nex AI Crop Screening Report'}</h3>
              <span className="crop-tag">Crop: {profile.crop} • Stage: {profile.cropStage}</span>
            </div>
          </div>

          <div className="results-body" style={{ whiteSpace: 'pre-wrap', lineHeight: '1.65' }}>
            {diagnosisResult}
          </div>

          <div className="results-footer-warning">
            <HelpCircle size={18} color="#0369a1" />
            <span>
              {profile.language === 'te'
                ? 'సహాయం: మీ సమీప వ్యవసాయ విస్తరణ అధికారి (MAO) లేదా కృషి విజ్ఞాన కేంద్రం (KVK) ను సంప్రదించండి.'
                : profile.language === 'hi'
                ? 'सहायता: आवश्यकता पड़ने पर अपने स्थानीय कृषि अधिकारी या कृषि विज्ञान केंद्र (KVK) से संपर्क करें।'
                : 'Need confirmation? Consult your local Mandal Agricultural Officer (MAO) or Krishi Vigyan Kendra (KVK).'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
