import React, { useState, useEffect } from 'react';
import { TRANSLATIONS } from '../translations';
import { CheckSquare, Square, Plus, Trash2, ListTodo, AlertCircle } from 'lucide-react';

export default function FarmTasks({ profile }) {
  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;

  const [tasks, setTasks] = useState(() => {
    const saved = localStorage.getItem('agrinex_tasks');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    // Default initial tasks in selected language
    return [
      { id: '1', title: profile.language === 'te' ? 'పొలంలో ఆకులపై తెగుళ్లు ఉన్నాయో లేదో గమనించండి' : profile.language === 'hi' ? 'खेत में पत्तियों पर कीटों और रोगों का निरीक्षण करें' : 'Inspect crop leaves for pests and diseases', completed: false },
      { id: '2', title: profile.language === 'te' ? 'నేలలో తేమ శాతాన్ని పరిశీలించి నీటి తడులు నిర్ణయించండి' : profile.language === 'hi' ? 'मिट्टी में नमी की जांच करें और सिंचाई योजना बनाएं' : 'Check soil moisture before planning irrigation', completed: false },
      { id: '3', title: profile.language === 'te' ? 'పొలం పనులకు ముందు నేటి వాతావరణ హెచ్చరికలు తనిఖీ చేయండి' : profile.language === 'hi' ? 'खेत कार्य शुरू करने से पहले मौसम पूर्वानुमान देखें' : 'Review weather forecast before spraying or fertilizing', completed: true }
    ];
  });

  const [newTaskText, setNewTaskText] = useState('');

  // Persist tasks in localStorage
  useEffect(() => {
    localStorage.setItem('agrinex_tasks', JSON.stringify(tasks));
  }, [tasks]);

  const handleAddTask = (e) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;

    const newTask = {
      id: Date.now().toString(),
      title: newTaskText.trim(),
      completed: false
    };

    setTasks([newTask, ...tasks]);
    setNewTaskText('');
  };

  const toggleTask = (id) => {
    setTasks(tasks.map(task => task.id === id ? { ...task, completed: !task.completed } : task));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  // Preset suggested actions
  const suggestedTemplates = [
    profile.language === 'te' ? 'పొలంలో కలుపు తీతను పరిశీలించండి' : profile.language === 'hi' ? 'खेत में खरपतवार नियंत्रण का निरीक्षण करें' : 'Inspect field weed growth',
    profile.language === 'te' ? 'బోరు / మోటారు పంపు నీటి ప్రవాహాన్ని తనిఖీ చేయండి' : profile.language === 'hi' ? 'ट्यूबवेल/सिंचाई पाइपलाइन की जांच करें' : 'Check irrigation pump & line pressure',
    profile.language === 'te' ? 'ఈ వారపు ఎరువుల ఖర్చులను రికార్డు చేయండి' : profile.language === 'hi' ? 'इस सप्ताह के खाद-बीज खर्च दर्ज करें' : 'Record this week fertilizer input expenses'
  ];

  return (
    <div className="tasks-container">
      <div className="tasks-header">
        <div className="tasks-title-group">
          <ListTodo size={26} color="#16a34a" />
          <div>
            <h2 className="title-text">{t.tasksTitle}</h2>
            <p className="subtitle-text">{t.tasksSubtitle}</p>
          </div>
        </div>
      </div>

      {/* Add Task Form */}
      <form onSubmit={handleAddTask} className="add-task-form">
        <input
          type="text"
          className="task-input-field"
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          placeholder={t.addTaskPlaceholder}
        />
        <button type="submit" className="add-task-btn" disabled={!newTaskText.trim()}>
          <Plus size={18} />
          <span>{t.addTaskBtn}</span>
        </button>
      </form>

      {/* Suggested Quick Task Add */}
      <div className="suggested-tasks-box">
        <span className="suggested-label">{t.suggestedTasksTitle}:</span>
        <div className="suggested-task-chips">
          {suggestedTemplates.map((template, idx) => (
            <button
              key={idx}
              type="button"
              className="task-template-chip"
              onClick={() => {
                const newTask = { id: Date.now().toString(), title: template, completed: false };
                setTasks([newTask, ...tasks]);
              }}
            >
              + {template}
            </button>
          ))}
        </div>
      </div>

      {/* Task List */}
      <div className="tasks-list-wrapper">
        {tasks.length === 0 ? (
          <div className="empty-tasks-card">
            <p>{t.noTasks}</p>
          </div>
        ) : (
          tasks.map(task => (
            <div key={task.id} className={`task-item-card ${task.completed ? 'completed' : ''}`}>
              <button
                type="button"
                className="task-checkbox-btn"
                onClick={() => toggleTask(task.id)}
                title={task.completed ? 'Mark pending' : 'Mark done'}
              >
                {task.completed ? (
                  <CheckSquare size={22} color="#16a34a" />
                ) : (
                  <Square size={22} color="#94a3b8" />
                )}
              </button>

              <span className="task-title-text" onClick={() => toggleTask(task.id)}>
                {task.title}
              </span>

              <button
                type="button"
                className="delete-task-btn"
                onClick={() => deleteTask(task.id)}
                title={t.deleteTask}
              >
                <Trash2 size={18} />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
