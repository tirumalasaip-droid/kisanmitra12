import React, { useState, useMemo } from 'react';
import {
  Search, Shield, ExternalLink, ChevronDown, ChevronUp,
  CheckCircle2, AlertTriangle, Info, X, Filter, FileText,
  HelpCircle, ArrowLeft,
} from 'lucide-react';
import { TRANSLATIONS } from '../translations';
import {
  GOVERNMENT_SCHEMES,
  SCHEME_CATEGORIES,
  ALL_STATES,
  checkEligibility,
} from '../schemesData';

/* ─── tiny helpers ─────────────────────────────────────────────────── */
const t3 = (obj, lang) => (obj && (obj[lang] || obj.en)) || '';

const STATUS_LABELS = {
  active:  { en: 'Active', te: 'క్రియాశీలం', hi: 'सक्रिय', color: '#16a34a', bg: '#dcfce7' },
  ongoing: { en: 'Ongoing', te: 'కొనసాగుతోంది', hi: 'जारी', color: '#0284c7', bg: '#e0f2fe' },
  closed:  { en: 'Closed', te: 'మూసివేయబడింది', hi: 'बंद', color: '#dc2626', bg: '#fee2e2' },
};

const CAT_COLORS = {
  central:    { bg: '#ede9fe', color: '#7c3aed' },
  insurance:  { bg: '#fef3c7', color: '#d97706' },
  credit:     { bg: '#dcfce7', color: '#15803d' },
  irrigation: { bg: '#e0f2fe', color: '#0284c7' },
  state:      { bg: '#fce7f3', color: '#be185d' },
  market:     { bg: '#f0fdf4', color: '#166534' },
  soil:       { bg: '#fef9c3', color: '#92400e' },
};

/* ─── Eligibility Checker ────────────────────────────────────────────── */
function EligibilityChecker({ scheme, lang, onClose }) {
  const [answers, setAnswers] = useState({
    state: '',
    hasLand: null,
    hasAadhaarAndBank: null,
    isIncomeTaxPayer: false,
  });
  const [result, setResult] = useState(null);

  const labels = {
    en: {
      title: 'Eligibility Check',
      disclaimer: 'This is a preliminary check only. "Potentially Eligible" does not guarantee approval. Always verify with the official portal or your local agriculture office.',
      q_state: 'Your state / UT:',
      q_land: 'Do you own agricultural land (patta/khata in your name)?',
      q_bank: 'Do you have an Aadhaar-linked bank account?',
      q_tax: 'Do you file Income Tax returns? (Relevant for PM-KISAN)',
      yes: 'Yes', no: 'No',
      check: 'Check Eligibility', reset: 'Reset',
      likely: '✅ Potentially Eligible',
      possible: '⚠️ Possibly Eligible — review carefully',
      unlikely: '❌ May Not Be Eligible',
    },
    te: {
      title: 'అర్హత తనిఖీ',
      disclaimer: 'ఇది ప్రాథమిక తనిఖీ మాత్రమే. "అర్హత కలిగి ఉండవచ్చు" అంటే ఆమోదం హామీ కాదు. ఎల్లప్పుడూ అధికారిక పోర్టల్ లేదా స్థానిక వ్యవసాయ కార్యాలయంతో ధృవీకరించండి.',
      q_state: 'మీ రాష్ట్రం / యూటీ:',
      q_land: 'మీ పేరు మీద వ్యవసాయ భూమి (పట్టా/ఖాతా) ఉందా?',
      q_bank: 'మీకు ఆధార్ అనుసంధానమైన బ్యాంక్ ఖాతా ఉందా?',
      q_tax: 'మీరు ఆదాయపు పన్ను రిటర్న్ దాఖలు చేస్తారా? (PM-KISAN కు సంబంధించినది)',
      yes: 'అవును', no: 'కాదు',
      check: 'అర్హతను తనిఖీ చేయండి', reset: 'రీసెట్',
      likely: '✅ అర్హత కలిగి ఉండవచ్చు',
      possible: '⚠️ అర్హత కలిగి ఉండవచ్చు — జాగ్రత్తగా సమీక్షించండి',
      unlikely: '❌ అర్హత లేకపోవచ్చు',
    },
    hi: {
      title: 'पात्रता जाँच',
      disclaimer: 'यह केवल प्रारंभिक जाँच है। "संभावित रूप से पात्र" होने का अर्थ अनुमोदन की गारंटी नहीं है। हमेशा आधिकारिक पोर्टल या स्थानीय कृषि कार्यालय से सत्यापित करें।',
      q_state: 'आपका राज्य / UT:',
      q_land: 'क्या आपके नाम पर कृषि भूमि (पट्टा/खाता) है?',
      q_bank: 'क्या आपके पास आधार-लिंक्ड बैंक खाता है?',
      q_tax: 'क्या आप आयकर रिटर्न दाखिल करते हैं? (PM-KISAN के लिए प्रासंगिक)',
      yes: 'हाँ', no: 'नहीं',
      check: 'पात्रता जाँचें', reset: 'रीसेट',
      likely: '✅ संभावित रूप से पात्र',
      possible: '⚠️ संभवतः पात्र — ध्यान से समीक्षा करें',
      unlikely: '❌ पात्र नहीं हो सकते',
    },
  };
  const L = labels[lang] || labels.en;

  const canCheck = answers.state && answers.hasLand !== null && answers.hasAadhaarAndBank !== null;

  const handleCheck = () => {
    setResult(checkEligibility(scheme, answers, lang));
  };

  const resultColors = result ? {
    likely:   { bg: '#dcfce7', border: '#16a34a', text: '#15803d' },
    possible: { bg: '#fef3c7', border: '#d97706', text: '#92400e' },
    unlikely: { bg: '#fee2e2', border: '#dc2626', text: '#b91c1c' },
  }[result.status] : null;

  return (
    <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 12, padding: 16, marginTop: 12 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <h4 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#1e293b', display: 'flex', alignItems: 'center', gap: 6 }}>
          <HelpCircle size={16} color="#7c3aed" /> {L.title}
        </h4>
        <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 2 }}>
          <X size={18} color="#64748b" />
        </button>
      </div>

      <div style={{ background: '#fffbeb', border: '1px solid #fbbf24', borderRadius: 8, padding: '8px 12px', fontSize: 12, color: '#92400e', marginBottom: 12, lineHeight: 1.5 }}>
        <Info size={13} style={{ marginRight: 4, verticalAlign: 'middle' }} />
        {L.disclaimer}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {/* State */}
        <div>
          <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>{L.q_state}</label>
          <select
            value={answers.state}
            onChange={e => setAnswers(a => ({ ...a, state: e.target.value }))}
            style={{ width: '100%', padding: '8px 10px', borderRadius: 8, border: '1px solid #cbd5e1', fontSize: 13 }}
          >
            <option value="">— {lang === 'te' ? 'ఎంచుకోండి' : lang === 'hi' ? 'चुनें' : 'Select'} —</option>
            {ALL_STATES.filter(s => s !== 'All India').map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        {/* Land */}
        <div>
          <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>{L.q_land}</label>
          <div style={{ display: 'flex', gap: 8 }}>
            {[true, false].map(v => (
              <button key={String(v)} onClick={() => setAnswers(a => ({ ...a, hasLand: v }))}
                style={{ flex: 1, padding: '7px 0', borderRadius: 8, border: `2px solid ${answers.hasLand === v ? '#16a34a' : '#cbd5e1'}`, background: answers.hasLand === v ? '#dcfce7' : '#fff', fontWeight: 600, fontSize: 13, cursor: 'pointer', color: '#1e293b' }}>
                {v ? L.yes : L.no}
              </button>
            ))}
          </div>
        </div>

        {/* Aadhaar + Bank */}
        <div>
          <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>{L.q_bank}</label>
          <div style={{ display: 'flex', gap: 8 }}>
            {[true, false].map(v => (
              <button key={String(v)} onClick={() => setAnswers(a => ({ ...a, hasAadhaarAndBank: v }))}
                style={{ flex: 1, padding: '7px 0', borderRadius: 8, border: `2px solid ${answers.hasAadhaarAndBank === v ? '#16a34a' : '#cbd5e1'}`, background: answers.hasAadhaarAndBank === v ? '#dcfce7' : '#fff', fontWeight: 600, fontSize: 13, cursor: 'pointer', color: '#1e293b' }}>
                {v ? L.yes : L.no}
              </button>
            ))}
          </div>
        </div>

        {/* Income tax — only show for PM-KISAN */}
        {scheme.id === 'pm-kisan' && (
          <div>
            <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>{L.q_tax}</label>
            <div style={{ display: 'flex', gap: 8 }}>
              {[true, false].map(v => (
                <button key={String(v)} onClick={() => setAnswers(a => ({ ...a, isIncomeTaxPayer: v }))}
                  style={{ flex: 1, padding: '7px 0', borderRadius: 8, border: `2px solid ${answers.isIncomeTaxPayer === v ? '#16a34a' : '#cbd5e1'}`, background: answers.isIncomeTaxPayer === v ? '#dcfce7' : '#fff', fontWeight: 600, fontSize: 13, cursor: 'pointer', color: '#1e293b' }}>
                  {v ? L.yes : L.no}
                </button>
              ))}
            </div>
          </div>
        )}

        <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
          <button onClick={handleCheck} disabled={!canCheck}
            style={{ flex: 2, padding: '10px 0', borderRadius: 10, background: canCheck ? '#15803d' : '#cbd5e1', color: '#fff', fontWeight: 700, fontSize: 14, border: 'none', cursor: canCheck ? 'pointer' : 'not-allowed' }}>
            {L.check}
          </button>
          <button onClick={() => { setAnswers({ state: '', hasLand: null, hasAadhaarAndBank: null, isIncomeTaxPayer: false }); setResult(null); }}
            style={{ flex: 1, padding: '10px 0', borderRadius: 10, background: '#f1f5f9', color: '#475569', fontWeight: 600, fontSize: 13, border: '1px solid #cbd5e1', cursor: 'pointer' }}>
            {L.reset}
          </button>
        </div>
      </div>

      {result && resultColors && (
        <div style={{ marginTop: 14, padding: '12px 14px', borderRadius: 10, background: resultColors.bg, border: `2px solid ${resultColors.border}` }}>
          <p style={{ margin: 0, fontWeight: 700, fontSize: 15, color: resultColors.text }}>
            {L[result.status]}
          </p>
          {result.reasons.length > 0 && (
            <ul style={{ margin: '8px 0 0 0', paddingLeft: 18, fontSize: 13, color: resultColors.text }}>
              {result.reasons.map((r, i) => <li key={i} style={{ marginBottom: 3 }}>{r}</li>)}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

/* ─── Scheme Card ───────────────────────────────────────────────────── */
function SchemeCard({ scheme, lang }) {
  const [expanded, setExpanded] = useState(false);
  const [showChecker, setShowChecker] = useState(false);

  const catStyle = CAT_COLORS[scheme.category] || CAT_COLORS.central;
  const statusInfo = STATUS_LABELS[scheme.status] || STATUS_LABELS.active;
  const catLabel = t3(SCHEME_CATEGORIES[scheme.category], lang);

  const checkerLabel = lang === 'te' ? 'అర్హత తనిఖీ' : lang === 'hi' ? 'पात्रता जाँच' : 'Check Eligibility';
  const applyLabel   = lang === 'te' ? 'అధికారిక సైట్' : lang === 'hi' ? 'आधिकारिक साइट' : 'Official Site';
  const docsLabel    = lang === 'te' ? 'అవసరమైన పత్రాలు' : lang === 'hi' ? 'आवश्यक दस्तावेज़' : 'Documents Required';
  const howLabel     = lang === 'te' ? 'దరఖాస్తు విధానం' : lang === 'hi' ? 'आवेदन प्रक्रिया' : 'Application Process';
  const deadlineLabel = lang === 'te' ? 'గడువు' : lang === 'hi' ? 'अंतिम तारीख' : 'Deadline';
  const verifiedLabel = lang === 'te' ? 'ధృవీకరించబడింది' : lang === 'hi' ? 'सत्यापित' : 'Verified';
  const unverifiedLabel = lang === 'te' ? 'అపరిశీలిత' : lang === 'hi' ? 'असत्यापित' : 'Unverified';
  const lastVerifiedLabel = lang === 'te' ? 'చివరగా ధృవీకరించబడింది' : lang === 'hi' ? 'अंतिम सत्यापन' : 'Last Verified';
  const sourceLabel = lang === 'te' ? 'మూల పత్రం' : lang === 'hi' ? 'स्रोत' : 'Source';

  return (
    <div style={{
      background: '#fff',
      borderRadius: 14,
      border: '1px solid #e2e8f0',
      overflow: 'hidden',
      marginBottom: 12,
      boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
    }}>
      {/* Header */}
      <div style={{ padding: '14px 16px', cursor: 'pointer' }} onClick={() => setExpanded(e => !e)}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            {/* Category + Status chips */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 6 }}>
              <span style={{ fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 20, background: catStyle.bg, color: catStyle.color }}>
                {catLabel}
              </span>
              <span style={{ fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 20, background: statusInfo.bg, color: statusInfo.color }}>
                {t3(statusInfo, lang)}
              </span>
              {!scheme.isVerified && (
                <span style={{ fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 20, background: '#fee2e2', color: '#dc2626' }}>
                  ⚠ {unverifiedLabel}
                </span>
              )}
              {scheme.isVerified && (
                <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 20, background: '#f0fdf4', color: '#16a34a', display: 'flex', alignItems: 'center', gap: 3 }}>
                  <CheckCircle2 size={11} /> {verifiedLabel}
                </span>
              )}
            </div>

            {/* Name */}
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#1e293b', lineHeight: 1.4 }}>
              {t3(scheme.name, lang)}
            </h3>

            {/* States */}
            <p style={{ margin: '4px 0 0', fontSize: 12, color: '#64748b' }}>
              {scheme.states.join(' · ')}
            </p>
          </div>

          <div style={{ flexShrink: 0, marginTop: 2 }}>
            {expanded ? <ChevronUp size={20} color="#64748b" /> : <ChevronDown size={20} color="#64748b" />}
          </div>
        </div>

        {/* Benefits summary (always visible) */}
        <p style={{ margin: '10px 0 0', fontSize: 13, color: '#334155', lineHeight: 1.55 }}>
          {t3(scheme.benefits, lang)}
        </p>
      </div>

      {/* Expanded details */}
      {expanded && (
        <div style={{ borderTop: '1px solid #f1f5f9', padding: '14px 16px', background: '#fafafa' }}>

          {/* Eligibility */}
          <DetailSection
            title={lang === 'te' ? 'అర్హత నిబంధనలు' : lang === 'hi' ? 'पात्रता शर्तें' : 'Eligibility Criteria'}
            items={scheme.eligibility[lang] || scheme.eligibility.en}
            icon={<CheckCircle2 size={14} color="#15803d" />}
          />

          {/* Documents */}
          <DetailSection
            title={docsLabel}
            items={scheme.documents[lang] || scheme.documents.en}
            icon={<FileText size={14} color="#0284c7" />}
          />

          {/* Application Process */}
          <div style={{ marginBottom: 12 }}>
            <p style={{ margin: '0 0 4px', fontSize: 12, fontWeight: 700, color: '#475569', textTransform: 'uppercase', letterSpacing: 0.5 }}>{howLabel}</p>
            <p style={{ margin: 0, fontSize: 13, color: '#334155', lineHeight: 1.55 }}>{t3(scheme.applicationProcess, lang)}</p>
          </div>

          {/* Deadline */}
          <div style={{ marginBottom: 12 }}>
            <p style={{ margin: '0 0 4px', fontSize: 12, fontWeight: 700, color: '#475569', textTransform: 'uppercase', letterSpacing: 0.5 }}>{deadlineLabel}</p>
            <p style={{ margin: 0, fontSize: 13, color: '#334155' }}>{t3(scheme.deadline, lang)}</p>
          </div>

          {/* Data integrity row */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center', marginBottom: 14, padding: '8px 12px', background: '#f1f5f9', borderRadius: 8 }}>
            <span style={{ fontSize: 12, color: '#64748b' }}>
              📅 {lastVerifiedLabel}: <strong>{scheme.lastVerified}</strong>
            </span>
            <a href={scheme.sourceLink} target="_blank" rel="noopener noreferrer"
              style={{ fontSize: 12, color: '#0284c7', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 3 }}>
              <ExternalLink size={11} /> {sourceLabel}
            </a>
          </div>

          {/* Unverified warning */}
          {!scheme.isVerified && (
            <div style={{ background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 8, padding: '10px 12px', marginBottom: 14, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <AlertTriangle size={16} color="#dc2626" style={{ flexShrink: 0, marginTop: 2 }} />
              <p style={{ margin: 0, fontSize: 12, color: '#b91c1c', lineHeight: 1.5 }}>
                {lang === 'te'
                  ? 'ఈ పథకం యొక్క కొన్ని వివరాలు పూర్తిగా ధృవీకరించబడలేదు. అధికారిక ప్రభుత్వ పోర్టల్ లో తనిఖీ చేయండి.'
                  : lang === 'hi'
                  ? 'इस योजना के कुछ विवरण पूरी तरह सत्यापित नहीं हैं। आधिकारिक सरकारी पोर्टल पर जाँचें।'
                  : 'Some details for this scheme could not be fully verified. Please check the official government portal.'}
              </p>
            </div>
          )}

          {/* Action buttons */}
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <a href={scheme.officialLink} target="_blank" rel="noopener noreferrer"
              style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '9px 16px', background: '#15803d', color: '#fff', borderRadius: 10, fontWeight: 700, fontSize: 13, textDecoration: 'none' }}>
              <ExternalLink size={14} /> {applyLabel}
            </a>
            <button
              onClick={() => setShowChecker(s => !s)}
              style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '9px 16px', background: '#ede9fe', color: '#7c3aed', borderRadius: 10, fontWeight: 700, fontSize: 13, border: 'none', cursor: 'pointer' }}>
              <HelpCircle size={14} /> {checkerLabel}
            </button>
          </div>

          {/* Eligibility checker */}
          {showChecker && (
            <EligibilityChecker scheme={scheme} lang={lang} onClose={() => setShowChecker(false)} />
          )}
        </div>
      )}
    </div>
  );
}

function DetailSection({ title, items, icon }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <p style={{ margin: '0 0 6px', fontSize: 12, fontWeight: 700, color: '#475569', textTransform: 'uppercase', letterSpacing: 0.5 }}>{title}</p>
      <ul style={{ margin: 0, paddingLeft: 0, listStyle: 'none' }}>
        {(items || []).map((item, i) => (
          <li key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 6, marginBottom: 4, fontSize: 13, color: '#334155', lineHeight: 1.5 }}>
            <span style={{ flexShrink: 0, marginTop: 2 }}>{icon}</span>
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ─── Main View ─────────────────────────────────────────────────────── */
export default function GovernmentSchemesView({ profile }) {
  const lang = profile?.language || 'en';
  const t = TRANSLATIONS[lang] || TRANSLATIONS.en;

  const [search, setSearch] = useState('');
  const [filterState, setFilterState] = useState('All India');
  const [filterCat, setFilterCat] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showFilters, setShowFilters] = useState(false);

  const UI = {
    en: {
      heading: 'Govt. Schemes & Subsidies',
      sub: 'Official Indian government agricultural programs',
      notice: 'All data sourced from official government portals only. Never invented. See "Last Verified" date per scheme.',
      searchPlaceholder: 'Search schemes…',
      filterBtn: 'Filters',
      stateLabel: 'State',
      catLabel: 'Category',
      statusLabel: 'Status',
      allStates: 'All States',
      allCats: 'All Categories',
      allStatus: 'All Status',
      active: 'Active',
      closed: 'Closed',
      noResults: 'No schemes found matching your filters.',
      schemeCount: (n) => `${n} scheme${n !== 1 ? 's' : ''} found`,
    },
    te: {
      heading: 'సర్కార్ పథకాలు & సబ్సిడీలు',
      sub: 'అధికారిక భారత ప్రభుత్వ వ్యవసాయ కార్యక్రమాలు',
      notice: 'అన్ని డేటా అధికారిక ప్రభుత్వ పోర్టళ్ల నుండి మాత్రమే. ఎప్పుడూ కల్పించలేదు. ప్రతి పథకానికి "చివరగా ధృవీకరించబడింది" తేదీ చూడండి.',
      searchPlaceholder: 'పథకాలను శోధించండి…',
      filterBtn: 'ఫిల్టర్లు',
      stateLabel: 'రాష్ట్రం',
      catLabel: 'వర్గం',
      statusLabel: 'స్థితి',
      allStates: 'అన్ని రాష్ట్రాలు',
      allCats: 'అన్ని వర్గాలు',
      allStatus: 'అన్ని స్థితులు',
      active: 'క్రియాశీలం',
      closed: 'మూసివేయబడింది',
      noResults: 'మీ ఫిల్టర్లకు సరిపోలే పథకాలు కేవలం కనుగొనబడలేదు.',
      schemeCount: (n) => `${n} పథకాలు కనుగొనబడ్డాయి`,
    },
    hi: {
      heading: 'सरकारी योजनाएं और सब्सिडी',
      sub: 'आधिकारिक भारत सरकार कृषि कार्यक्रम',
      notice: 'सभी डेटा केवल आधिकारिक सरकारी पोर्टलों से। कभी नहीं बनाया गया। प्रत्येक योजना पर "अंतिम सत्यापन" तारीख देखें।',
      searchPlaceholder: 'योजनाएं खोजें…',
      filterBtn: 'फ़िल्टर',
      stateLabel: 'राज्य',
      catLabel: 'श्रेणी',
      statusLabel: 'स्थिति',
      allStates: 'सभी राज्य',
      allCats: 'सभी श्रेणियां',
      allStatus: 'सभी स्थिति',
      active: 'सक्रिय',
      closed: 'बंद',
      noResults: 'आपके फ़िल्टर से मेल खाती कोई योजना नहीं मिली।',
      schemeCount: (n) => `${n} योजनाएं मिलीं`,
    },
  };
  const L = UI[lang] || UI.en;

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return GOVERNMENT_SCHEMES.filter(s => {
      // text search
      if (q) {
        const name = t3(s.name, lang).toLowerCase();
        const ben  = t3(s.benefits, lang).toLowerCase();
        if (!name.includes(q) && !ben.includes(q)) return false;
      }
      // state filter
      if (filterState !== 'All India') {
        if (!s.states.includes('All India') && !s.states.includes(filterState)) return false;
      }
      // category filter
      if (filterCat !== 'all' && s.category !== filterCat) return false;
      // status filter
      if (filterStatus !== 'all' && s.status !== filterStatus) return false;
      return true;
    });
  }, [search, filterState, filterCat, filterStatus, lang]);

  const selectStyle = {
    padding: '8px 10px', borderRadius: 8, border: '1px solid #cbd5e1',
    fontSize: 13, background: '#fff', color: '#1e293b', width: '100%',
  };

  return (
    <div className="calc-container" style={{ paddingBottom: 32 }}>

      {/* Page header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
        <div style={{ width: 38, height: 38, borderRadius: 10, background: '#ede9fe', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Shield size={20} color="#7c3aed" />
        </div>
        <div>
          <h2 style={{ margin: 0, fontSize: 18, fontWeight: 800, color: '#1e293b' }}>{L.heading}</h2>
          <p style={{ margin: 0, fontSize: 12, color: '#64748b' }}>{L.sub}</p>
        </div>
      </div>

      {/* Data integrity notice */}
      <div style={{ background: '#f0fdf4', border: '1px solid #86efac', borderRadius: 10, padding: '10px 14px', marginBottom: 14, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
        <CheckCircle2 size={16} color="#16a34a" style={{ flexShrink: 0, marginTop: 1 }} />
        <p style={{ margin: 0, fontSize: 12, color: '#166534', lineHeight: 1.55 }}>{L.notice}</p>
      </div>

      {/* Search bar */}
      <div style={{ position: 'relative', marginBottom: 10 }}>
        <Search size={16} color="#94a3b8" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
        <input
          type="text"
          placeholder={L.searchPlaceholder}
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ width: '100%', padding: '10px 12px 10px 36px', borderRadius: 10, border: '1px solid #cbd5e1', fontSize: 14, boxSizing: 'border-box', outline: 'none' }}
        />
        {search && (
          <button onClick={() => setSearch('')} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', padding: 2 }}>
            <X size={15} color="#94a3b8" />
          </button>
        )}
      </div>

      {/* Filter toggle */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <span style={{ fontSize: 13, color: '#64748b' }}>{L.schemeCount(filtered.length)}</span>
        <button
          onClick={() => setShowFilters(f => !f)}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', borderRadius: 10, border: '1px solid #cbd5e1', background: showFilters ? '#f1f5f9' : '#fff', fontSize: 13, fontWeight: 600, color: '#475569', cursor: 'pointer' }}>
          <Filter size={14} />
          {L.filterBtn}
          {showFilters ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </button>
      </div>

      {/* Filters panel */}
      {showFilters && (
        <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 12, padding: 14, marginBottom: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {/* State */}
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>{L.stateLabel}</label>
            <select value={filterState} onChange={e => setFilterState(e.target.value)} style={selectStyle}>
              <option value="All India">{L.allStates}</option>
              {ALL_STATES.filter(s => s !== 'All India').map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          {/* Category */}
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>{L.catLabel}</label>
            <select value={filterCat} onChange={e => setFilterCat(e.target.value)} style={selectStyle}>
              <option value="all">{L.allCats}</option>
              {Object.entries(SCHEME_CATEGORIES).map(([key, val]) => (
                <option key={key} value={key}>{t3(val, lang)}</option>
              ))}
            </select>
          </div>

          {/* Status */}
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>{L.statusLabel}</label>
            <div style={{ display: 'flex', gap: 8 }}>
              {['all', 'active', 'closed'].map(v => (
                <button key={v} onClick={() => setFilterStatus(v)}
                  style={{ flex: 1, padding: '7px 0', borderRadius: 8, border: `2px solid ${filterStatus === v ? '#15803d' : '#cbd5e1'}`, background: filterStatus === v ? '#dcfce7' : '#fff', fontWeight: 600, fontSize: 13, cursor: 'pointer', color: '#1e293b' }}>
                  {v === 'all' ? L.allStatus : v === 'active' ? L.active : L.closed}
                </button>
              ))}
            </div>
          </div>

          {/* Reset filters */}
          {(filterState !== 'All India' || filterCat !== 'all' || filterStatus !== 'all') && (
            <button onClick={() => { setFilterState('All India'); setFilterCat('all'); setFilterStatus('all'); }}
              style={{ alignSelf: 'flex-end', fontSize: 12, fontWeight: 600, color: '#dc2626', background: 'none', border: 'none', cursor: 'pointer', padding: '4px 0', display: 'flex', alignItems: 'center', gap: 4 }}>
              <X size={13} />
              {lang === 'te' ? 'ఫిల్టర్లు రీసెట్' : lang === 'hi' ? 'फ़िल्टर रीसेट' : 'Reset Filters'}
            </button>
          )}
        </div>
      )}

      {/* Scheme list */}
      {filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px 20px', color: '#94a3b8', fontSize: 14 }}>
          <Shield size={36} color="#cbd5e1" style={{ marginBottom: 10 }} />
          <p style={{ margin: 0 }}>{L.noResults}</p>
        </div>
      ) : (
        filtered.map(s => <SchemeCard key={s.id} scheme={s} lang={lang} />)
      )}

      {/* Bottom disclaimer */}
      <div style={{ background: '#fef9c3', border: '1px solid #fde68a', borderRadius: 10, padding: '12px 14px', marginTop: 8 }}>
        <p style={{ margin: 0, fontSize: 12, color: '#92400e', lineHeight: 1.6 }}>
          {lang === 'te'
            ? '⚠️ ఈ సమాచారం అధికారిక ప్రభుత్వ వెబ్‌సైట్ల నుండి సేకరించబడింది. పథకాల వివరాలు, మొత్తాలు మరియు గడువు తేదీలు మారవచ్చు. దయచేసి దరఖాస్తు చేసే ముందు అధికారిక పోర్టల్ ని తనిఖీ చేయండి.'
            : lang === 'hi'
            ? '⚠️ यह जानकारी आधिकारिक सरकारी वेबसाइटों से एकत्र की गई है। योजनाओं के विवरण, राशियाँ और अंतिम तारीखें बदल सकती हैं। आवेदन करने से पहले कृपया आधिकारिक पोर्टल जाँचें।'
            : '⚠️ This information is gathered from official government websites. Scheme details, amounts, and deadlines may change. Please check the official portal before applying.'}
        </p>
      </div>
    </div>
  );
}
