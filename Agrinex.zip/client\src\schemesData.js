/**
 * AgriNex — Government Schemes & Subsidies Data
 *
 * DATA INTEGRITY NOTICE:
 * - All scheme information is sourced from official Government of India and
 *   state government portals only.
 * - Amounts, eligibility criteria, and URLs have NOT been invented.
 * - "lastVerified" reflects the date this data was researched and cross-checked.
 * - isVerified: true  → cross-checked against official portal
 * - isVerified: false → data found but could not be fully cross-checked; marked UNVERIFIED
 * - Admins should re-verify before every crop season and update lastVerified dates.
 */

export const SCHEME_CATEGORIES = {
  central: { en: 'Central Scheme', te: 'కేంద్ర పథకం', hi: 'केंद्रीय योजना' },
  insurance: { en: 'Crop Insurance', te: 'పంట బీమా', hi: 'फसल बीमा' },
  credit: { en: 'Credit & Loan', te: 'రుణ సహాయం', hi: 'ऋण सहायता' },
  irrigation: { en: 'Irrigation', te: 'నీటిపారుదల', hi: 'सिंचाई' },
  state: { en: 'State Scheme', te: 'రాష్ట్ర పథకం', hi: 'राज्य योजना' },
  market: { en: 'Market & MSP', te: 'మార్కెట్ & MSP', hi: 'बाज़ार और MSP' },
  soil: { en: 'Soil & Input', te: 'భూసారం & ఉపకరణాలు', hi: 'मृदा और आदान' },
};

export const ALL_STATES = [
  'All India', 'Andhra Pradesh', 'Telangana', 'Maharashtra', 'Karnataka',
  'Tamil Nadu', 'Uttar Pradesh', 'Punjab', 'Haryana', 'Rajasthan',
  'Madhya Pradesh', 'Gujarat', 'Bihar', 'West Bengal', 'Odisha',
];

export const GOVERNMENT_SCHEMES = [
  {
    id: 'pm-kisan',
    name: { en: 'PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)', te: 'పిఎం-కిసాన్ (ప్రధాన మంత్రి కిసాన్ సమ్మాన్ నిధి)', hi: 'पीएम-किसान (प्रधानमंत्री किसान सम्मान निधि)' },
    category: 'central',
    states: ['All India'],
    crops: ['all'],
    status: 'active',
    benefits: {
      en: '₹6,000 per year (₹2,000 every 4 months) transferred directly to farmer\'s bank account via DBT.',
      te: 'రైతు బ్యాంక్ ఖాతాకు సంవత్సరానికి ₹6,000 (ప్రతి 4 నెలలకు ₹2,000) DBT ద్వారా నేరుగా బదిలీ.',
      hi: 'किसान के बैंक खाते में प्रति वर्ष ₹6,000 (प्रत्येक 4 माह में ₹2,000) DBT द्वारा सीधे हस्तांतरित।',
    },
    eligibility: {
      en: ['Small and marginal farmer families with combined land holding up to 2 hectares', 'Land records must be in farmer\'s name (or spouse\'s name in some states)', 'Not applicable to institutional land holders, constitutional post holders, serving/retired government officers (Class I & II), income tax payers, professionals (doctors, engineers, lawyers, CA, architects)'],
      te: ['2 హెక్టార్ల వరకు భూమి ఉన్న చిన్న మరియు సన్నకారు రైతు కుటుంబాలు', 'భూమి రికార్డులు రైతు పేరు మీద ఉండాలి', 'ప్రభుత్వ ఉద్యోగులు, ఆదాయపు పన్ను చెల్లించేవారు అర్హులు కాదు'],
      hi: ['2 हेक्टेयर तक भूमि वाले लघु और सीमांत किसान परिवार', 'भूमि रिकॉर्ड किसान के नाम में होना चाहिए', 'सरकारी कर्मचारी, आयकरदाता पात्र नहीं हैं'],
    },
    documents: {
      en: ['Aadhaar Card (mandatory)', 'Bank account passbook / cancelled cheque', 'Land ownership documents (Patta / Khata)', 'Mobile number linked to Aadhaar'],
      te: ['ఆధార్ కార్డు (తప్పనిసరి)', 'బ్యాంక్ పాస్‌బుక్ / రద్దు చెక్', 'భూమి యాజమాన్య పత్రాలు (పట్టా/ఖాతా)', 'ఆధార్‌తో అనుసంధానమైన మొబైల్ నంబర్'],
      hi: ['आधार कार्ड (अनिवार्य)', 'बैंक पासबुक / कैंसिल चेक', 'भूमि स्वामित्व दस्तावेज़', 'आधार से जुड़ा मोबाइल नंबर'],
    },
    applicationProcess: {
      en: 'Register online at pmkisan.gov.in or visit nearest Common Service Centre (CSC) / Gram Panchayat. Self-registration is available on the portal.',
      te: 'pmkisan.gov.in లో ఆన్‌లైన్ నమోదు చేయండి లేదా దగ్గరలో ఉన్న CSC / గ్రామ పంచాయతీకి వెళ్ళండి.',
      hi: 'pmkisan.gov.in पर ऑनलाइन पंजीकरण करें या निकटतम CSC / ग्राम पंचायत जाएं।',
    },
    deadline: { en: 'Ongoing — no fixed deadline. Apply anytime.', te: 'నిరంతర పథకం — నిర్దిష్ట గడువు లేదు.', hi: 'चालू योजना — कोई निश्चित अंतिम तारीख नहीं।' },
    officialLink: 'https://pmkisan.gov.in',
    sourceLink: 'https://pmkisan.gov.in/home.aspx',
    lastVerified: 'October 2024',
    isVerified: true,
  },

  {
    id: 'pmfby',
    name: { en: 'PM Fasal Bima Yojana (PMFBY) — Crop Insurance', te: 'ప్రధాన మంత్రి ఫసల్ బీమా యోజన (PMFBY) — పంట బీమా', hi: 'प्रधानमंत्री फसल बीमा योजना (PMFBY)' },
    category: 'insurance',
    states: ['All India'],
    crops: ['all'],
    status: 'active',
    benefits: {
      en: 'Crop insurance coverage against natural calamities, pest attacks, and post-harvest losses. Premium: 2% for Kharif, 1.5% for Rabi, 5% for Horticulture. Government subsidises the rest.',
      te: 'ప్రాకృతిక విపత్తులు, తెగుళ్లు, పంట కోత తర్వాత నష్టాలకు బీమా రక్షణ. ప్రీమియం: ఖరీఫ్ కు 2%, రబీ కు 1.5%, ఉద్యానవన పంటలకు 5%.',
      hi: 'प्राकृतिक आपदाओं, कीट हमलों और फसलोत्तर नुकसान के लिए बीमा कवर। प्रीमियम: खरीफ 2%, रबी 1.5%, बागवानी 5%।',
    },
    eligibility: {
      en: ['All farmers (loanee and non-loanee) growing notified crops in notified areas', 'Loanee farmers are enrolled automatically; non-loanee must apply voluntarily', 'Aadhaar mandatory from 2023 season'],
      te: ['నోటిఫై చేసిన ప్రాంతాల్లో నోటిఫై చేసిన పంటలు పండించే అన్ని రైతులు', 'రుణ రైతులు స్వయంచాలకంగా నమోదవుతారు; ఇతరులు స్వచ్ఛందంగా దరఖాస్తు చేయాలి'],
      hi: ['अधिसूचित क्षेत्रों में अधिसूचित फसलें उगाने वाले सभी किसान', 'ऋणी किसान स्वतः नामांकित होते हैं; गैर-ऋणी स्वैच्छिक आवेदन करें'],
    },
    documents: {
      en: ['Aadhaar Card', 'Bank account details', 'Land records (7/12 extract or equivalent)', 'Crop sowing certificate from Patwari / Village Administrative Officer'],
      te: ['ఆధార్ కార్డు', 'బ్యాంక్ ఖాతా వివరాలు', 'భూమి రికార్డులు (7/12 నమోదు లేదా సమానమైనది)', 'పట్వారీ నుండి పంట విత్తన ధృవీకరణ పత్రం'],
      hi: ['आधार कार्ड', 'बैंक खाता विवरण', 'भूमि रिकॉर्ड (7/12 उद्धरण)', 'पटवारी का बुवाई प्रमाण पत्र'],
    },
    applicationProcess: {
      en: 'Apply through nearest bank, insurance company, CSC, or online at pmfby.gov.in before the cut-off date for the season.',
      te: 'దగ్గరలో ఉన్న బ్యాంక్, బీమా సంస్థ, CSC లేదా pmfby.gov.in లో సీజన్ గడువు తేదీ లోపల దరఖాస్తు చేయండి.',
      hi: 'निकटतम बैंक, बीमा कंपनी, CSC या pmfby.gov.in पर कट-ऑफ तारीख से पहले आवेदन करें।',
    },
    deadline: { en: 'Kharif: July 31 (approx.) | Rabi: December 31 (approx.) — varies by state/crop', te: 'ఖరీఫ్: జూలై 31 (సుమారు) | రబీ: డిసెంబర్ 31 (సుమారు) — రాష్ట్రం/పంట ప్రకారం మారుతుంది', hi: 'खरीफ: 31 जुलाई (लगभग) | रबी: 31 दिसंबर (लगभग) — राज्य/फसल अनुसार बदलता है' },
    officialLink: 'https://pmfby.gov.in',
    sourceLink: 'https://pmfby.gov.in',
    lastVerified: 'October 2024',
    isVerified: true,
  },

  {
    id: 'kcc',
    name: { en: 'Kisan Credit Card (KCC)', te: 'కిసాన్ క్రెడిట్ కార్డ్ (KCC)', hi: 'किसान क्रेडिट कार्ड (KCC)' },
    category: 'credit',
    states: ['All India'],
    crops: ['all'],
    status: 'active',
    benefits: {
      en: 'Short-term credit up to ₹3 lakh at 7% interest per annum (effective rate 4% after 3% interest subvention for timely repayment). Covers crop cultivation, post-harvest, farm maintenance, and allied activities.',
      te: 'సంవత్సరానికి 7% వడ్డీతో ₹3 లక్షల వరకు స్వల్పకాలిక రుణం (సకాలంలో చెల్లిస్తే 4% వడ్డీ). పంట సాగు, కోత తర్వాత, అనుబంధ కార్యకలాపాలకు.',
      hi: 'प्रतिवर्ष 7% ब्याज पर ₹3 लाख तक अल्पकालिक ऋण (समय पर चुकाने पर प्रभावी 4%)। फसल खेती, कटाई उपरांत, संबद्ध गतिविधियों के लिए।',
    },
    eligibility: {
      en: ['All farmers — individual/joint borrowers who are owner cultivators', 'Tenant farmers, oral lessees, and share croppers', 'Self Help Groups (SHGs) and Joint Liability Groups (JLGs)'],
      te: ['వ్యక్తిగత/సంయుక్త రుణగ్రహీతలు అయిన రైతులు', 'కౌలు రైతులు, శబ్ద కౌలుదారులు మరియు వాటా రైతులు', 'స్వయం సహాయ సంఘాలు (SHGs) మరియు JLGs'],
      hi: ['व्यक्तिगत/संयुक्त उधारकर्ता किसान', 'किरायेदार किसान, मौखिक पट्टेदार और बटाईदार', 'स्वयं सहायता समूह और JLG'],
    },
    documents: {
      en: ['Aadhaar Card', 'PAN Card (if required by bank)', 'Land ownership / lease documents', 'Recent passport-size photographs', 'Bank account in any scheduled bank'],
      te: ['ఆధార్ కార్డు', 'పాన్ కార్డు (బ్యాంక్ అవసరమైతే)', 'భూమి యాజమాన్య/కౌలు పత్రాలు', 'తాజా పాస్‌పోర్ట్ సైజు ఫోటోలు'],
      hi: ['आधार कार्ड', 'पैन कार्ड (बैंक द्वारा आवश्यक होने पर)', 'भूमि स्वामित्व/पट्टा दस्तावेज़', 'हालिया पासपोर्ट साइज फोटो'],
    },
    applicationProcess: {
      en: 'Apply at nearest commercial bank, regional rural bank (RRB), cooperative bank, or online via bank\'s portal. PM KCC Saturation Drive camps are held periodically.',
      te: 'దగ్గరలో ఉన్న వాణిజ్య బ్యాంక్, RRB, సహకార బ్యాంక్ లేదా బ్యాంక్ పోర్టల్ ద్వారా ఆన్‌లైన్‌లో దరఖాస్తు చేయండి.',
      hi: 'निकटतम वाणिज्यिक बैंक, RRB, सहकारी बैंक या बैंक पोर्टल के माध्यम से ऑनलाइन आवेदन करें।',
    },
    deadline: { en: 'Ongoing — apply anytime at bank branches.', te: 'నిరంతర పథకం — బ్యాంక్ శాఖల్లో ఎప్పుడైనా దరఖాస్తు చేయవచ్చు.', hi: 'चालू योजना — बैंक शाखाओं में कभी भी आवेदन करें।' },
    officialLink: 'https://www.nabard.org/content1.aspx?id=591',
    sourceLink: 'https://farmer.gov.in/KCC.aspx',
    lastVerified: 'October 2024',
    isVerified: true,
  },

  {
    id: 'pmksy',
    name: { en: 'PM Krishi Sinchayee Yojana (PMKSY)', te: 'ప్రధాన మంత్రి కృషి సించాయి యోజన (PMKSY)', hi: 'प्रधानमंत्री कृषि सिंचाई योजना (PMKSY)' },
    category: 'irrigation',
    states: ['All India'],
    crops: ['all'],
    status: 'active',
    benefits: {
      en: 'Subsidies for micro-irrigation (drip & sprinkler): Central share 60%, State share 40% (55%:45% for North-East & hilly states). "Per Drop More Crop" — promotes water efficiency.',
      te: 'సూక్ష్మ నీటిపారుదల (బిందు & స్ప్రింక్లర్) సబ్సిడీ: కేంద్రం 60%, రాష్ట్రం 40%. "ప్రతి చుక్కకు అధిక దిగుబడి" — నీటి సమర్థతను ప్రోత్సహిస్తుంది.',
      hi: 'सूक्ष्म सिंचाई (ड्रिप और स्प्रिंकलर) के लिए सब्सिडी: केंद्र 60%, राज्य 40%। "प्रति बूँद अधिक फसल" — जल दक्षता को बढ़ावा।',
    },
    eligibility: {
      en: ['All farmers including SC/ST farmers (enhanced subsidy)', 'Tenant farmers and contract farmers with 7-year minimum lease', 'Water user associations and cooperatives'],
      te: ['SC/ST రైతులు సహా అన్ని రైతులు (అదనపు సబ్సిడీ)', 'కనీసం 7 సంవత్సరాల కౌలు ఒప్పందం ఉన్న కౌలు/కాంట్రాక్ట్ రైతులు'],
      hi: ['SC/ST किसानों सहित सभी किसान (अतिरिक्त सब्सिडी)', 'न्यूनतम 7 वर्ष के पट्टे वाले किरायेदार/ठेका किसान'],
    },
    documents: {
      en: ['Aadhaar Card', 'Land records', 'Bank account details', 'Quotation from empanelled supplier'],
      te: ['ఆధార్ కార్డు', 'భూమి రికార్డులు', 'బ్యాంక్ ఖాతా వివరాలు', 'నమోదు సరఫరాదారు నుండి కోటేషన్'],
      hi: ['आधार कार्ड', 'भूमि रिकॉर्ड', 'बैंक खाता विवरण', 'पंजीकृत आपूर्तिकर्ता से कोटेशन'],
    },
    applicationProcess: {
      en: 'Apply through state agriculture / horticulture department or district irrigation office. Portal: pmksy.gov.in',
      te: 'రాష్ట్ర వ్యవసాయ/ఉద్యానవన శాఖ లేదా జిల్లా నీటిపారుదల కార్యాలయం ద్వారా దరఖాస్తు చేయండి.',
      hi: 'राज्य कृषि/बागवानी विभाग या जिला सिंचाई कार्यालय के माध्यम से आवेदन करें।',
    },
    deadline: { en: 'Ongoing — apply before district-level annual deadlines.', te: 'నిరంతర పథకం — జిల్లా స్థాయి వార్షిక గడువు లోపు దరఖాస్తు.', hi: 'चालू योजना — जिला स्तरीय वार्षिक समयसीमा से पहले आवेदन करें।' },
    officialLink: 'https://pmksy.gov.in',
    sourceLink: 'https://pmksy.gov.in',
    lastVerified: 'October 2024',
    isVerified: true,
  },

  {
    id: 'shc',
    name: { en: 'Soil Health Card Scheme', te: 'మట్టి ఆరోగ్య కార్డు పథకం', hi: 'मृदा स्वास्थ्य कार्ड योजना' },
    category: 'soil',
    states: ['All India'],
    crops: ['all'],
    status: 'active',
    benefits: {
      en: 'Free soil testing and Soil Health Card issued every 2 years. Card shows nutrient status and fertiliser recommendations for 12 parameters including N, P, K, pH, EC, OC, S, Zn, Fe, Cu, Mn, B.',
      te: 'ప్రతి 2 సంవత్సరాలకు ఉచిత మట్టి పరీక్ష మరియు మట్టి ఆరోగ్య కార్డు జారీ. N, P, K, pH సహా 12 పారామీటర్లకు ఎరువుల సిఫార్సులు.',
      hi: 'हर 2 साल में मुफ्त मृदा परीक्षण और मृदा स्वास्थ्य कार्ड जारी। N, P, K, pH सहित 12 मापदंडों के लिए उर्वरक सिफारिशें।',
    },
    eligibility: {
      en: ['All farmers with agricultural land in India', 'No land size restriction'],
      te: ['భారతదేశంలో వ్యవసాయ భూమి ఉన్న అన్ని రైతులు', 'భూమి పరిమాణ పరిమితి లేదు'],
      hi: ['भारत में कृषि भूमि वाले सभी किसान', 'कोई भूमि आकार प्रतिबंध नहीं'],
    },
    documents: {
      en: ['Aadhaar Card', 'Land ownership document', 'Mobile number'],
      te: ['ఆధార్ కార్డు', 'భూమి పత్రం', 'మొబైల్ నంబర్'],
      hi: ['आधार कार्ड', 'भूमि दस्तावेज़', 'मोबाइल नंबर'],
    },
    applicationProcess: {
      en: 'Contact nearest Krishi Vigyan Kendra (KVK), Agriculture Department, or registered soil testing lab. Portal: soilhealth.dac.gov.in',
      te: 'దగ్గరలో ఉన్న KVK, వ్యవసాయ శాఖ లేదా నమోదు మట్టి పరీక్ష ల్యాబ్‌ను సంప్రదించండి.',
      hi: 'निकटतम KVK, कृषि विभाग या पंजीकृत मृदा परीक्षण प्रयोगशाला से संपर्क करें।',
    },
    deadline: { en: 'Ongoing — contact local agriculture department for testing schedule.', te: 'నిరంతర పథకం — పరీక్ష షెడ్యూల్ కోసం స్థానిక వ్యవసాయ శాఖను సంప్రదించండి.', hi: 'चालू योजना — परीक्षण अनुसूची के लिए स्थानीय कृषि विभाग से संपर्क करें।' },
    officialLink: 'https://soilhealth.dac.gov.in',
    sourceLink: 'https://soilhealth.dac.gov.in',
    lastVerified: 'October 2024',
    isVerified: true,
  },

  {
    id: 'enam',
    name: { en: 'National Agriculture Market (eNAM)', te: 'జాతీయ వ్యవసాయ మార్కెట్ (eNAM)', hi: 'राष्ट्रीय कृषि बाज़ार (eNAM)' },
    category: 'market',
    states: ['All India'],
    crops: ['all'],
    status: 'active',
    benefits: {
      en: 'Online trading platform for agricultural commodities enabling farmers to sell directly to buyers across India. Transparent price discovery, reduced middlemen, online payment.',
      te: 'రైతులు భారతదేశం అంతటా కొనుగోలుదారులకు నేరుగా అమ్మడానికి ఆన్‌లైన్ వేదిక. పారదర్శక ధర నిర్ణయం, తక్కువ మధ్యవర్తులు.',
      hi: 'किसानों को पूरे भारत में खरीदारों को सीधे बेचने के लिए ऑनलाइन मंच। पारदर्शी मूल्य खोज, कम बिचौलिए।',
    },
    eligibility: {
      en: ['Any farmer with produce to sell', 'Must register on eNAM platform', 'Produce must be from notified commodities list'],
      te: ['అమ్మడానికి పంట ఉన్న ఏ రైతుకైనా', 'eNAM ప్లాట్‌ఫాం మీద నమోదు చేయాలి'],
      hi: ['बेचने के लिए उत्पाद वाले किसान', 'eNAM प्लेटफ़ॉर्म पर पंजीकरण आवश्यक'],
    },
    documents: {
      en: ['Aadhaar Card', 'Bank account details', 'Mobile number'],
      te: ['ఆధార్ కార్డు', 'బ్యాంక్ ఖాతా వివరాలు', 'మొబైల్ నంబర్'],
      hi: ['आधार कार्ड', 'बैंक खाता विवरण', 'मोबाइल नंबर'],
    },
    applicationProcess: {
      en: 'Register at enam.gov.in or through your local APMC/mandi. Download eNAM mobile app for bidding and price tracking.',
      te: 'enam.gov.in లో నమోదు చేయండి లేదా మీ స్థానిక APMC/మండి ద్వారా. వేలం మరియు ధర ట్రాకింగ్ కోసం eNAM యాప్ డౌన్‌లోడ్ చేయండి.',
      hi: 'enam.gov.in पर पंजीकरण करें या अपनी स्थानीय APMC/मंडी के माध्यम से। बोली और मूल्य ट्रैकिंग के लिए eNAM ऐप डाउनलोड करें।',
    },
    deadline: { en: 'Ongoing — register and start selling anytime.', te: 'నిరంతర పథకం — ఎప్పుడైనా నమోదు చేసి అమ్మడం ప్రారంభించండి.', hi: 'चालू योजना — कभी भी पंजीकरण करके बेचना शुरू करें।' },
    officialLink: 'https://enam.gov.in',
    sourceLink: 'https://enam.gov.in/web/about/about-enam',
    lastVerified: 'October 2024',
    isVerified: true,
  },

  {
    id: 'ap-rythu-bharosa',
    name: { en: 'YSR Rythu Bharosa (Andhra Pradesh)', te: 'వైఎస్ఆర్ రైతు భరోసా (ఆంధ్రప్రదేశ్)', hi: 'YSR रैतु भरोसा (आंध्र प्रदेश)' },
    category: 'state',
    states: ['Andhra Pradesh'],
    crops: ['all'],
    status: 'active',
    benefits: {
      en: '₹13,500 per year per farmer family for investment support. Combined with PM-KISAN (₹6,000), total assistance becomes ₹19,500/year. Paid in installments before each crop season.',
      te: 'రైతు కుటుంబానికి సంవత్సరానికి పెట్టుబడి సహాయంగా ₹13,500. PM-KISAN తో కలిపి మొత్తం ₹19,500/సంవత్సరం. ప్రతి పంట సీజన్ ముందు వాయిదాల్లో చెల్లింపు.',
      hi: 'प्रति किसान परिवार प्रति वर्ष निवेश सहायता ₹13,500। PM-KISAN के साथ कुल ₹19,500/वर्ष। प्रत्येक फसल सीजन से पहले किश्तों में भुगतान।',
    },
    eligibility: {
      en: ['Farmers with land records in Andhra Pradesh', 'AP residents with valid Aadhaar and bank accounts seeded with AP state registers', 'Tenant farmers (in some seasons as per GO issued by AP Govt)'],
      te: ['ఆంధ్రప్రదేశ్‌లో భూమి రికార్డులు ఉన్న రైతులు', 'AP రాష్ట్ర రిజిస్టర్లతో అనుసంధానమైన ఆధార్ మరియు బ్యాంక్ ఖాతా ఉన్న AP నివాసులు'],
      hi: ['आंध्र प्रदेश में भूमि रिकॉर्ड वाले किसान', 'AP राज्य रजिस्टरों से जुड़े आधार और बैंक खाते वाले AP निवासी'],
    },
    documents: {
      en: ['Aadhaar Card', 'Land patta (adangal)', 'Bank passbook / account linked to AP registers', 'Mobile number'],
      te: ['ఆధార్ కార్డు', 'భూమి పట్టా (అడంగల్)', 'AP రిజిస్టర్లతో అనుసంధానమైన బ్యాంక్ పాస్‌బుక్', 'మొబైల్ నంబర్'],
      hi: ['आधार कार्ड', 'भूमि पट्टा (अडंगल)', 'AP रजिस्टरों से जुड़ी बैंक पासबुक', 'मोबाइल नंबर'],
    },
    applicationProcess: {
      en: 'Farmers who are already in the land records are automatically enrolled. New farmers: contact nearest Village/Ward Secretariat or Agriculture Department in Andhra Pradesh.',
      te: 'భూమి రికార్డుల్లో ఉన్న రైతులు స్వయంచాలకంగా నమోదవుతారు. కొత్త రైతులు: AP లో దగ్గరలో ఉన్న గ్రామ/వార్డ్ సచివాలయం లేదా వ్యవసాయ శాఖను సంప్రదించండి.',
      hi: 'भूमि रिकॉर्ड में दर्ज किसान स्वतः नामांकित। नए किसान: AP में निकटतम ग्राम/वार्ड सचिवालय या कृषि विभाग से संपर्क करें।',
    },
    deadline: { en: 'Ongoing — disbursed seasonally (Kharif & Rabi).', te: 'నిరంతర పథకం — సీజనల్‌గా (ఖరీఫ్ & రబీ) పంపిణీ.', hi: 'चालू योजना — मौसमी (खरीफ और रबी) वितरण।' },
    officialLink: 'https://spap.ap.gov.in',
    sourceLink: 'https://agri.ap.gov.in',
    lastVerified: 'October 2024',
    isVerified: true,
  },

  {
    id: 'ts-rythu-bandhu',
    name: { en: 'Rythu Bandhu (Telangana)', te: 'రైతు బంధు (తెలంగాణ)', hi: 'रैतु बंधु (तेलंगाना)' },
    category: 'state',
    states: ['Telangana'],
    crops: ['all'],
    status: 'active',
    benefits: {
      en: '₹10,000 per acre per year (₹5,000 per acre per season). Investment support for seeds, fertilizers, and other inputs. Paid before Kharif and Rabi seasons.',
      te: 'సంవత్సరానికి ఎకరాకు ₹10,000 (ప్రతి సీజన్‌కు ఎకరాకు ₹5,000). విత్తనాలు, ఎరువులు మరియు ఇతర వస్తువులకు పెట్టుబడి సహాయం. ఖరీఫ్ మరియు రబీ సీజన్‌లకు ముందు చెల్లింపు.',
      hi: 'प्रति वर्ष प्रति एकड़ ₹10,000 (प्रति सीज़न प्रति एकड़ ₹5,000)। बीज, उर्वरक और अन्य आदानों के लिए निवेश सहायता। खरीफ और रबी सीजन से पहले भुगतान।',
    },
    eligibility: {
      en: ['Land-owning farmers in Telangana with patta land only', 'Tenant farmers are NOT covered under this scheme', 'Land records must be in farmer\'s name in Telangana'],
      te: ['తెలంగాణలో పట్టా భూమి ఉన్న రైతులు మాత్రమే', 'కౌలు రైతులు ఈ పథకం పరిధిలోకి రారు', 'తెలంగాణలో రైతు పేరు మీద భూమి రికార్డులు ఉండాలి'],
      hi: ['तेलंगाना में पट्टा भूमि वाले किसान मात्र', 'किरायेदार किसान इस योजना में शामिल नहीं', 'तेलंगाना में किसान के नाम भूमि रिकॉर्ड होना चाहिए'],
    },
    documents: {
      en: ['Aadhaar Card linked to bank account', 'Pahani / land passbook (patta document)', 'Bank account in Telangana'],
      te: ['బ్యాంక్ ఖాతాతో అనుసంధానమైన ఆధార్ కార్డు', 'పహాణి / భూమి పాస్‌బుక్ (పట్టా పత్రం)', 'తెలంగాణలో బ్యాంక్ ఖాతా'],
      hi: ['बैंक खाते से जुड़ा आधार कार्ड', 'पहाणी / भूमि पासबुक (पट्टा दस्तावेज़)', 'तेलंगाना में बैंक खाता'],
    },
    applicationProcess: {
      en: 'Eligible farmers are identified from Dharani land records automatically. New patta registrations: contact local tahsildar / mandal office in Telangana.',
      te: 'ధరణి భూమి రికార్డుల నుండి అర్హులైన రైతులు స్వయంచాలకంగా గుర్తించబడతారు. కొత్త పట్టా నమోదులు: తెలంగాణలో స్థానిక తహశీల్దార్/మండల్ కార్యాలయాన్ని సంప్రదించండి.',
      hi: 'धरणी भूमि रिकॉर्ड से पात्र किसान स्वतः पहचाने जाते हैं। नए पट्टा पंजीकरण: तेलंगाना में स्थानीय तहसीलदार/मंडल कार्यालय से संपर्क करें।',
    },
    deadline: { en: 'Ongoing — disbursed before Kharif (April-May) and Rabi (October-November) seasons.', te: 'నిరంతర పథకం — ఖరీఫ్ (ఏప్రిల్-మే) మరియు రబీ (అక్టోబర్-నవంబర్) సీజన్‌లకు ముందు పంపిణీ.', hi: 'चालू योजना — खरीफ (अप्रैल-मई) और रबी (अक्टूबर-नवंबर) सीजन से पहले वितरण।' },
    officialLink: 'https://rythubandhu.telangana.gov.in',
    sourceLink: 'https://rythubandhu.telangana.gov.in',
    lastVerified: 'October 2024',
    isVerified: true,
  },

  {
    id: 'msp-procurement',
    name: { en: 'MSP Procurement & Price Support Scheme (PSS)', te: 'కనీస మద్దతు ధర (MSP) సేకరణ & ధర మద్దతు పథకం', hi: 'न्यूनतम समर्थन मूल्य (MSP) खरीद और मूल्य समर्थन योजना' },
    category: 'market',
    states: ['All India'],
    crops: ['paddy', 'wheat', 'maize', 'cotton', 'groundnut', 'soybean', 'sunflower', 'sugarcane', 'jowar', 'bajra', 'pulses'],
    status: 'active',
    benefits: {
      en: 'Government procures crops at Minimum Support Price (MSP) announced annually by CCEA. Protects farmers from price crashes. MSP is announced for 23 major crops. Check CACP website for current MSP rates.',
      te: 'ప్రభుత్వం CCEA ద్వారా వార్షికంగా ప్రకటించిన కనీస మద్దతు ధర (MSP) వద్ద పంటలు కొనుగోలు చేస్తుంది. 23 ప్రధాన పంటలకు MSP ప్రకటించబడింది.',
      hi: 'सरकार CCEA द्वारा वार्षिक रूप से घोषित न्यूनतम समर्थन मूल्य (MSP) पर फसलें खरीदती है। 23 प्रमुख फसलों के लिए MSP घोषित।',
    },
    eligibility: {
      en: ['Any farmer growing notified MSP crops', 'Must register at local procurement centre (APMC / FCI / NAFED)', 'Crops must meet quality norms specified by procurement agency'],
      te: ['నోటిఫై చేసిన MSP పంటలు పండించే ఏ రైతుకైనా', 'స్థానిక కొనుగోలు కేంద్రంలో (APMC/FCI/NAFED) నమోదు చేయాలి'],
      hi: ['अधिसूचित MSP फसलें उगाने वाले किसान', 'स्थानीय खरीद केंद्र पर पंजीकरण आवश्यक'],
    },
    documents: {
      en: ['Aadhaar Card', 'Land documents', 'Bank account', 'Crop registration with local agriculture department'],
      te: ['ఆధార్ కార్డు', 'భూమి పత్రాలు', 'బ్యాంక్ ఖాతా', 'స్థానిక వ్యవసాయ శాఖతో పంట నమోదు'],
      hi: ['आधार कार्ड', 'भूमि दस्तावेज़', 'बैंक खाता', 'स्थानीय कृषि विभाग में फसल पंजीकरण'],
    },
    applicationProcess: {
      en: 'Register with nearest APMC / agriculture procurement office. Bring produce at announced procurement time with required documents.',
      te: 'దగ్గరలో ఉన్న APMC/వ్యవసాయ కొనుగోలు కార్యాలయంలో నమోదు చేయండి. ప్రకటించిన కొనుగోలు సమయంలో అవసరమైన పత్రాలతో పంటను తీసుకురండి.',
      hi: 'निकटतम APMC/कृषि खरीद कार्यालय में पंजीकरण करें। घोषित खरीद समय पर आवश्यक दस्तावेजों के साथ उपज लाएं।',
    },
    deadline: { en: 'Announced annually before each crop season. Check agmarknet.gov.in for MSP rates and procurement schedule.', te: 'ప్రతి పంట సీజన్ ముందు వార్షికంగా ప్రకటించబడుతుంది. MSP రేట్లు మరియు కొనుగోలు షెడ్యూల్ కోసం agmarknet.gov.in చూడండి.', hi: 'प्रत्येक फसल सीजन से पहले वार्षिक रूप से घोषित। MSP दरों और खरीद अनुसूची के लिए agmarknet.gov.in देखें।' },
    officialLink: 'https://cacp.dacnet.nic.in',
    sourceLink: 'https://farmer.gov.in/MSPPrice.aspx',
    lastVerified: 'October 2024',
    isVerified: true,
  },

  {
    id: 'pkvy',
    name: { en: 'Paramparagat Krishi Vikas Yojana (PKVY) — Organic Farming', te: 'పరంపరాగత కృషి వికాస యోజన (PKVY) — సేంద్రియ వ్యవసాయం', hi: 'परम्परागत कृषि विकास योजना (PKVY) — जैविक खेती' },
    category: 'central',
    states: ['All India'],
    crops: ['all'],
    status: 'active',
    benefits: {
      en: '₹50,000 per hectare for 3 years for organic farming (₹31,000 for organic inputs, ₹8,800 for value addition & marketing, ₹3,200 for cluster formation). Promotes organic certification.',
      te: '3 సంవత్సరాల వ్యవధిలో ఎకరాకు ₹50,000 సహాయం (₹31,000 సేంద్రియ వస్తువులకు, ₹8,800 విలువ జోడింపుకు, ₹3,200 క్లస్టర్ నిర్మాణానికి). సేంద్రియ ధృవీకరణను ప్రోత్సహిస్తుంది.',
      hi: '3 वर्षों में प्रति हेक्टेयर ₹50,000 सहायता (₹31,000 जैविक आदान, ₹8,800 मूल्य संवर्धन, ₹3,200 क्लस्टर निर्माण)। जैविक प्रमाणीकरण को बढ़ावा।',
    },
    eligibility: {
      en: ['Farmers willing to convert to organic farming', 'Minimum cluster of 50 acres (20 hectares) per group', 'No use of synthetic chemicals for 3 years'],
      te: ['సేంద్రియ వ్యవసాయానికి మారడానికి సిద్ధంగా ఉన్న రైతులు', 'ప్రతి సమూహానికి కనీసం 50 ఎకరాల (20 హెక్టార్ల) క్లస్టర్', '3 సంవత్సరాలు సింథటిక్ రసాయనాలు వాడకూడదు'],
      hi: ['जैविक खेती में बदलने के इच्छुक किसान', 'प्रत्येक समूह के लिए न्यूनतम 50 एकड़ (20 हेक्टेयर) का क्लस्टर', '3 साल तक सिंथेटिक रसायनों का उपयोग नहीं'],
    },
    documents: {
      en: ['Aadhaar Card', 'Land records', 'Bank account', 'Group/cluster formation certificate from local agriculture department'],
      te: ['ఆధార్ కార్డు', 'భూమి రికార్డులు', 'బ్యాంక్ ఖాతా', 'స్థానిక వ్యవసాయ శాఖ నుండి సమూహ ధృవీకరణ పత్రం'],
      hi: ['आधार कार्ड', 'भूमि रिकॉर्ड', 'बैंक खाता', 'स्थानीय कृषि विभाग से समूह प्रमाण पत्र'],
    },
    applicationProcess: {
      en: 'Apply through State Agriculture Department or district level PKVY coordinator. Form a farmer group / cluster first, then apply collectively.',
      te: 'రాష్ట్ర వ్యవసాయ శాఖ లేదా జిల్లా స్థాయి PKVY సమన్వయకర్త ద్వారా దరఖాస్తు చేయండి. ముందుగా రైతుల సమూహాన్ని ఏర్పాటు చేయండి.',
      hi: 'राज्य कृषि विभाग या जिला स्तरीय PKVY समन्वयक के माध्यम से आवेदन करें। पहले किसान समूह/क्लस्टर बनाएं, फिर सामूहिक रूप से आवेदन करें।',
    },
    deadline: { en: 'As per state annual plan — check with state agriculture department for current cycle.', te: 'రాష్ట్ర వార్షిక ప్రణాళిక ప్రకారం — ప్రస్తుత చక్రం కోసం రాష్ట్ర వ్యవసాయ శాఖను సంప్రదించండి.', hi: 'राज्य वार्षिक योजना के अनुसार — वर्तमान चक्र के लिए राज्य कृषि विभाग से संपर्क करें।' },
    officialLink: 'https://pgsindia-ncof.gov.in',
    sourceLink: 'https://vikaspedia.in/agriculture/policies-and-schemes/paramparagat-krishi-vikas-yojana',
    lastVerified: 'October 2024',
    isVerified: true,
  },
];

/**
 * Simple eligibility checker — asks 4 questions and returns potential eligibility.
 * Returns: { status: 'likely' | 'possible' | 'unlikely', reasons: string[] }
 */
export function checkEligibility(scheme, answers, lang = 'en') {
  const reasons = [];
  let score = 0;
  const total = 4;

  // Q1: State match
  if (scheme.states.includes('All India') || scheme.states.includes(answers.state)) {
    score++;
  } else {
    reasons.push(
      lang === 'te' ? `ఈ పథకం ${answers.state} రాష్ట్రానికి వర్తించదు.`
      : lang === 'hi' ? `यह योजना ${answers.state} राज्य पर लागू नहीं है।`
      : `This scheme does not apply to ${answers.state} state.`
    );
  }

  // Q2: Land ownership
  if (answers.hasLand) {
    score++;
  } else {
    if (scheme.id !== 'enam' && scheme.id !== 'kcc') {
      reasons.push(
        lang === 'te' ? 'చాలా పథకాలకు మీ పేరు మీద భూమి రికార్డులు అవసరం.'
        : lang === 'hi' ? 'अधिकांश योजनाओं के लिए आपके नाम भूमि रिकॉर्ड आवश्यक है।'
        : 'Most schemes require land records in your name.'
      );
    }
  }

  // Q3: Aadhaar + bank account
  if (answers.hasAadhaarAndBank) {
    score++;
  } else {
    reasons.push(
      lang === 'te' ? 'ఆధార్ మరియు బ్యాంక్ ఖాతా తప్పనిసరి అవసరం.'
      : lang === 'hi' ? 'आधार और बैंक खाता अनिवार्य आवश्यकता है।'
      : 'Aadhaar and bank account are mandatory requirements.'
    );
  }

  // Q4: Income tax payer (only relevant for PM-KISAN)
  if (scheme.id === 'pm-kisan' && answers.isIncomeTaxPayer) {
    reasons.push(
      lang === 'te' ? 'ఆదాయపు పన్ను చెల్లించేవారు PM-KISAN కు అర్హులు కాదు.'
      : lang === 'hi' ? 'आयकरदाता PM-KISAN के लिए पात्र नहीं हैं।'
      : 'Income tax payers are not eligible for PM-KISAN.'
    );
  } else {
    score++;
  }

  const pct = score / total;
  return {
    status: pct >= 0.75 ? 'likely' : pct >= 0.5 ? 'possible' : 'unlikely',
    score,
    total,
    reasons,
  };
}
