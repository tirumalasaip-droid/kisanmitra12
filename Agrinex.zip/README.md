# AgriNex — Your Smart Farming Companion
*మీ స్మార్ట్ వ్యవసాయ నేస్తం | आपका स्मार्ट कृषि साथी*

AgriNex is a modern, mobile-first agricultural web application engineered for Indian farmers. It bridges cutting-edge AI guidance, genuine computer vision crop screening, and real farm weather data with accessibility in **Telugu (తెలుగు)**, **Hindi (हिन्दी)**, and **Indian English**.

---

## 🌟 Key Features

1. **Multilingual First-Time Onboarding**
   - Natural script in **Telugu**, **Hindi**, and **English**.
   - Respectful personalization preserving the farmer's name (e.g., *“నమస్కారం సూరి గారు!”*, *“नमस्ते सूरी जी!”*).
   - Selection of active or planned crop, growth stage (Planned, Newly Planted, Already Growing).
   - GPS device detection or manual pin selection via interactive OpenStreetMap/Leaflet map.
   - Profile settings and local storage persistence.

2. **Nex AI — Conversational Farming Assistant**
   - Secure backend integration using Google Gemini (`gemini-2.5-flash`).
   - Context-aware responses using the farmer's crop, growth stage, location, and real farm weather.
   - Low-token prompt design, actionable step-by-step field guidance.
   - Safety checks: rejects unsafe chemical recommendations and states uncertainty honestly.
   - Transparent fallback notification when API key is not configured.

3. **Three-Language Voice Assistant**
   - Full speech recognition (`te-IN`, `hi-IN`, `en-IN`) using Web Speech API.
   - Visual transcription review and edit before sending.
   - Text-to-speech audio reader with pause/stop functionality.
   - Graceful fallback for unsupported browsers or denied permissions.

4. **10 Guided Workflow Suggestions**
   - Instant tappable prompts translated into natural Telugu, Hindi, and English for weather forecasts, pest problems, planting season, irrigation, nutrients, task prioritization, and profit estimation.

5. **Crop Photo Vision Diagnosis**
   - Camera capture or photo upload of leaves, stems, or fruits.
   - Preliminary visual symptom screening powered by Gemini Vision.
   - Strict protocol: outlines visible clues, asks follow-up context questions, recommends safe cultural practices, and advises when Mandal Agricultural Officer (MAO) or Krishi Vigyan Kendra (KVK) consultation is required.

6. **Real Farm Weather & Honest Alerts**
   - Live weather fetched via Open-Meteo free API based on exact farm coordinates.
   - Current temperature, apparent temperature, humidity, rain, and wind speed.
   - 7-day forecast with daily rain probability and WMO weather condition descriptions in all three languages.
   - Honest, data-backed alerts generated only when conditions (extreme heat ≥38°C, heavy rain ≥20mm/65%, or strong winds ≥35 km/h) are forecasted.

7. **Farm Tasks & Reminders**
   - Create, complete, and delete daily agricultural tasks.
   - One-tap quick add suggestions (e.g. weed inspection, pump checks).
   - Local device persistence.

8. **Crop Profit & Expense Calculator**
   - Financial estimation tool with harvest quantities, market price per quintal, and expense breakdown (seeds, fertilizer, labor, irrigation, transport).
   - Net profit or loss calculation with cost-per-quintal metrics and clear estimates disclaimer.

9. **Soil Health Card Interpretation**
   - Soil test analysis for pH and NPK (Nitrogen, Phosphorus, Potassium) ratings.
   - Clear transparency notice stating phone cameras cannot measure soil chemistry and lab test values should be used.

10. **Market Mandi Rates**
    - Transparent APMC benchmarks with verified sources and dates.
    - Local rate entry tool for farmers to log their neighborhood sales.

---

## 🚀 Getting Started

### Prerequisites
- Node.js (v18+)
- npm or pnpm

### Installation

1. Clone or open the repository:
   ```bash
   cd AgriNex
   ```

2. Install dependencies:
   ```bash
   # Root backend dependencies
   npm install

   # Frontend client dependencies
   cd client
   npm install
   cd ..
   ```

3. Configure Environment Variables:
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   Add your Google Gemini API key (obtainable free from [Google AI Studio](https://aistudio.google.com/)):
   ```env
   PORT=5000
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
   *Note: If `GEMINI_API_KEY` is omitted, all weather, tasks, mapping, soil, and calculator features work completely, and Nex AI will display a clear configuration prompt.*

4. Build the client and start the server:
   ```bash
   # Build frontend assets
   npm --prefix client run build

   # Start the production Express server
   npm start
   ```

5. Open your browser:
   Visit **[http://localhost:5000](http://localhost:5000)**.

---

## 🛡️ Free-Service Limitations & Transparency

- **Weather API:** Uses Open-Meteo's non-commercial tier. It requires no API key and provides real coordinates-based forecasts.
- **AI Service:** Uses Google Gemini free-tier via `@google/genai`. Rate limits apply according to Google AI Studio quotas.
- **Maps:** Uses OpenStreetMap standard tiles with Leaflet.
- **Voice:** Leverages standard client-side Web Speech API supported in Chrome, Edge, and Android browsers.
