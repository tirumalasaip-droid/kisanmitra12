// Real weather service using Open-Meteo free API
// Retrieves actual weather data, precipitation probability, hourly details, and derives honest alerts

export async function fetchFarmWeather(latitude, longitude) {
  try {
    const lat = parseFloat(latitude) || 16.3067;
    const lon = parseFloat(longitude) || 80.4365;

    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max&timezone=auto`;

    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`Weather service returned HTTP ${res.status}`);
    }
    const data = await res.json();
    return { success: true, data };
  } catch (err) {
    console.error('[AgriNex Weather Error]', err);
    return { success: false, error: err.message };
  }
}

// Map WMO weather codes to descriptive labels in all 3 languages
export function getWeatherDescription(code, lang = 'en') {
  const codes = {
    0: { en: "Clear sky", te: "నిర్మలమైన ఆకాశం", hi: "साफ आसमान" },
    1: { en: "Mainly clear", te: "సాధారణంగా నిర్మలం", hi: "मुख्यतः साफ" },
    2: { en: "Partly cloudy", te: "పాక్షికంగా మేఘావృతం", hi: "आंशिक रूप से बादल" },
    3: { en: "Overcast", te: "మబ్బు పట్టింది", hi: "बादल छाए रहेंगे" },
    45: { en: "Foggy", te: "పొగమంచు", hi: "कोहरा" },
    48: { en: "Depositing rime fog", te: "దట్టమైన పొగమంచు", hi: "घना कोहरा" },
    51: { en: "Light drizzle", te: "తేలికపాటి తుంపర", hi: "हल्की बूंदाबांदी" },
    53: { en: "Moderate drizzle", te: "తుంపర వర్షం", hi: "मध्यम बूंदाबांदी" },
    55: { en: "Dense drizzle", te: "దట్టమైన చిరుజల్లులు", hi: "घनी बूंदाबांदी" },
    61: { en: "Slight rain", te: "తేలికపాటి వర్షం", hi: "हल्की बारिश" },
    63: { en: "Moderate rain", te: "మోస్తరు వర్షం", hi: "मध्यम बारिश" },
    65: { en: "Heavy rain", te: "భారీ వర్షం", hi: "भारी बारिश" },
    71: { en: "Slight snow fall", te: "తేలికపాటి మంచు", hi: "हल्की बर्फबारी" },
    80: { en: "Slight rain showers", te: "చిరు వర్షపు జల్లులు", hi: "हल्की बौछारें" },
    81: { en: "Moderate rain showers", te: "మోస్తరు వర్షపు జల్లులు", hi: "मध्यम बौछारें" },
    82: { en: "Violent rain showers", te: "తీవ్రమైన వర్షపు జల్లులు", hi: "तेज़ बौछारें" },
    95: { en: "Thunderstorm", te: "ఉరుములు మెరుపులతో కూడిన వర్షం", hi: "गरज के साथ बारिश" },
    96: { en: "Thunderstorm with slight hail", te: "వడగండ్ల వర్షం", hi: "ओलों के साथ आंधी" }
  };

  const item = codes[code] || { en: "Fair weather", te: "సాధారణ వాతావరణం", hi: "सामान्य मौसम" };
  return item[lang] || item.en;
}

// Generate personalized, data-backed alerts based on actual retrieved forecast
export function generateDataBackedAlerts(weatherData, farmerName, lang = 'en') {
  if (!weatherData || !weatherData.daily) return [];

  const alerts = [];
  const name = farmerName ? farmerName.trim() : '';
  const daily = weatherData.daily;

  const maxTempTomorrow = daily.temperature_2m_max?.[1] || daily.temperature_2m_max?.[0] || 0;
  const rainProbTomorrow = daily.precipitation_probability_max?.[1] || daily.precipitation_probability_max?.[0] || 0;
  const rainSumTomorrow = daily.precipitation_sum?.[1] || daily.precipitation_sum?.[0] || 0;
  const maxWindTomorrow = daily.wind_speed_10m_max?.[1] || daily.wind_speed_10m_max?.[0] || 0;

  // 1. Extreme Heat Alert (> 38°C)
  if (maxTempTomorrow >= 38) {
    if (lang === 'te') {
      alerts.push({
        type: 'warning',
        title: 'తీవ్రమైన ఎండ హెచ్చరిక',
        message: `${name ? name + ' గారు, ' : ''}రేపు మీ ప్రాంతంలో అధిక ఉష్ణోగ్రత (${maxTempTomorrow}°C) ఉండే అవకాశం ఉంది. పంటకు ఎండ తాకిడి తగలకుండా అవసరమైన నీటి పారుదల మరియు తేమ యాజమాన్యంపై శ్రద్ధ వహించండి.`
      });
    } else if (lang === 'hi') {
      alerts.push({
        type: 'warning',
        title: 'अत्यधिक गर्मी की चेतावनी',
        message: `${name ? name + ' जी, ' : ''}कल आपके क्षेत्र में उच्च तापमान (${maxTempTomorrow}°C) रहने की संभावना है। फसल को गर्मी से बचाने के लिए उचित सिंचाई प्रबंधन का ध्यान रखें।`
      });
    } else {
      alerts.push({
        type: 'warning',
        title: 'Extreme Heat Advisory',
        message: `${name ? name + ', ' : ''}high temperatures (${maxTempTomorrow}°C) are forecast tomorrow for your farm. Please plan field irrigation and moisture management carefully.`
      });
    }
  }

  // 2. Heavy Rain Alert (> 70% chance or > 25mm rain)
  if (rainProbTomorrow >= 65 || rainSumTomorrow >= 20) {
    if (lang === 'te') {
      alerts.push({
        type: 'caution',
        title: 'భారీ వర్ష సూచన హెచ్చరిక',
        message: `${name ? name + ' గారు, ' : ''}రేపు మీ ప్రాంతంలో వర్షం పడే అవకాశం (${rainProbTomorrow}%, సుమారు ${rainSumTomorrow} mm) ఉంది. పొలంలో నీరు నిల్వ ఉండకుండా మురుగు కాలువలను సిద్ధం చేసుకోండి. ఎరువులు లేదా రసాయనాల పిచికారీని తాత్కాలికంగా వాయిదా వేయండి.`
      });
    } else if (lang === 'hi') {
      alerts.push({
        type: 'caution',
        title: 'भारी वर्षा की चेतावनी',
        message: `${name ? name + ' जी, ' : ''}कल आपके क्षेत्र में बारिश की संभावना (${rainProbTomorrow}%, लगभग ${rainSumTomorrow} mm) है। खेत से अतिरिक्त जल निकासी की व्यवस्था करें और कीटनाशक/उर्वरक छिड़काव स्थगित रखें।`
      });
    } else {
      alerts.push({
        type: 'caution',
        title: 'Rain & Precipitation Advisory',
        message: `${name ? name + ', ' : ''}rain is expected tomorrow (${rainProbTomorrow}% chance, ~${rainSumTomorrow} mm). Ensure field drainage channels are clear and delay fertilizer/spray applications.`
      });
    }
  }

  // 3. High Wind Alert (> 35 km/h)
  if (maxWindTomorrow >= 35) {
    if (lang === 'te') {
      alerts.push({
        type: 'info',
        title: 'ఈదురు గాలుల సూచన',
        message: `${name ? name + ' గారు, ' : ''}రేపు గాలుల వేగం ${maxWindTomorrow} km/h వరకు పెరిగే అవకాశం ఉంది. పొడవాటి పంటలకు మరియు నారుమళ్ళకు ఆధారం కల్పించండి.`
      });
    } else if (lang === 'hi') {
      alerts.push({
        type: 'info',
        title: 'तेज़ हवा की चेतावनी',
        message: `${name ? name + ' जी, ' : ''}कल हवा की गति ${maxWindTomorrow} किमी/घंटा तक पहुँचने की संभावना है। लंबी फसलों को गिरने से बचाने के लिए सहारा दें।`
      });
    } else {
      alerts.push({
        type: 'info',
        title: 'Gusty Winds Advisory',
        message: `${name ? name + ', ' : ''}wind gusts up to ${maxWindTomorrow} km/h are expected tomorrow. Provide staking or support for tall crops where applicable.`
      });
    }
  }

  return alerts;
}
