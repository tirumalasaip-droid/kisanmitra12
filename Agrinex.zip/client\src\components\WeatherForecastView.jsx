import React, { useState } from 'react';
import { TRANSLATIONS } from '../translations';
import { CloudSun, Droplets, Wind, AlertTriangle, Info, Calendar, RefreshCw } from 'lucide-react';
import { getWeatherDescription } from '../weatherService';

export default function WeatherForecastView({ profile, weatherData, alerts, loading, onRefresh }) {
  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;
  const [selectedDayIndex, setSelectedDayIndex] = useState(0);

  const current = weatherData?.current;
  const daily = weatherData?.daily;

  return (
    <div className="weather-view-container">
      {/* Header */}
      <div className="weather-header-row">
        <div>
          <h2 className="title-text">{t.tabWeather}</h2>
          <p className="subtitle-text">
            📍 {profile.locationName} ({profile.coords?.lat?.toFixed(3)}, {profile.coords?.lng?.toFixed(3)})
          </p>
        </div>
        <button type="button" className="refresh-btn" onClick={onRefresh} disabled={loading} title="Refresh">
          <RefreshCw size={18} className={loading ? 'spin' : ''} />
          <span>{loading ? '...' : (profile.language === 'te' ? 'తాజాకరించు' : profile.language === 'hi' ? 'ताज़ा करें' : 'Refresh')}</span>
        </button>
      </div>

      {/* Real-time Data Alert Cards */}
      {alerts && alerts.length > 0 ? (
        <div className="alerts-stack">
          {alerts.map((al, idx) => (
            <div key={idx} className={`alert-banner-item banner-${al.type}`}>
              <AlertTriangle size={20} className="alert-icon" />
              <div className="alert-content">
                <strong className="alert-heading">{al.title}</strong>
                <p className="alert-text">{al.message}</p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="no-alert-banner">
          <Info size={18} color="#059669" />
          <span>{t.noAlerts}</span>
        </div>
      )}

      {/* Current Real Weather Card */}
      {current ? (
        <div className="current-weather-hero">
          <div className="hero-left">
            <span className="current-temp">{Math.round(current.temperature_2m)}°C</span>
            <span className="weather-desc">
              {getWeatherDescription(current.weather_code, profile.language)}
            </span>
            <span className="feels-like">
              {profile.language === 'te' ? 'స్పర్శకు ఉష్ణోగ్రత' : profile.language === 'hi' ? 'अनुभूत तापमान' : 'Feels like'} {Math.round(current.apparent_temperature)}°C
            </span>
          </div>

          <div className="hero-metrics-grid">
            <div className="metric-box">
              <Droplets size={18} color="#0284c7" />
              <span className="metric-val">{current.relative_humidity_2m}%</span>
              <span className="metric-lbl">{t.humidity}</span>
            </div>
            <div className="metric-box">
              <Wind size={18} color="#64748b" />
              <span className="metric-val">{current.wind_speed_10m} km/h</span>
              <span className="metric-lbl">{t.wind}</span>
            </div>
            <div className="metric-box">
              <CloudSun size={18} color="#eab308" />
              <span className="metric-val">{current.rain || 0} mm</span>
              <span className="metric-lbl">{t.rainDesc}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="loading-state-card">
          <p>{loading ? 'Loading real weather data...' : 'Weather data currently unavailable.'}</p>
        </div>
      )}

      {/* 7-Day Forecast Section */}
      {daily && daily.time && (
        <div className="forecast-section">
          <h3 className="section-title">
            <Calendar size={18} />
            <span>{t.viewHourly}</span>
          </h3>

          <div className="forecast-scroll-row">
            {daily.time.map((dateStr, i) => {
              const maxT = Math.round(daily.temperature_2m_max[i]);
              const minT = Math.round(daily.temperature_2m_min[i]);
              const rainChance = daily.precipitation_probability_max ? daily.precipitation_probability_max[i] : 0;
              const wCode = daily.weather_code[i];

              const d = new Date(dateStr);
              const dayName = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : d.toLocaleDateString(undefined, { weekday: 'short' });

              return (
                <div 
                  key={dateStr} 
                  className={`forecast-day-card ${selectedDayIndex === i ? 'active' : ''}`}
                  onClick={() => setSelectedDayIndex(i)}
                >
                  <div className="day-name">{dayName}</div>
                  <div className="forecast-temp-range">
                    <span className="max-t">{maxT}°</span>
                    <span className="min-t">{minT}°</span>
                  </div>
                  <div className="day-condition-label">
                    {getWeatherDescription(wCode, profile.language)}
                  </div>
                  <div className="rain-prob-pill">
                    💧 {rainChance}%
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
