import React from 'react';
import { TRANSLATIONS, COMMON_CROPS } from '../translations';
import { 
  Sprout, MapPin, CloudSun, AlertTriangle, CheckSquare, 
  Calculator, Layers, ShoppingBag, ArrowRight, ShieldCheck, Thermometer, Droplets, Wind, Shield
} from 'lucide-react';
import { getWeatherDescription } from '../weatherService';

export default function MainDashboard({ profile, weatherData, alerts, setActiveTab }) {
  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;

  // Personalized Greeting
  let greeting = '';
  if (profile.language === 'te') {
    greeting = `${t.greetingPrefix} ${profile.name} ${t.greetingSuffix}`;
  } else if (profile.language === 'hi') {
    greeting = `${t.greetingPrefix} ${profile.name} ${t.greetingSuffix}`;
  } else {
    greeting = `${t.greetingPrefix}, ${profile.name}!`;
  }

  const cropObj = COMMON_CROPS.find(c => c.id === profile.crop);
  const cropName = cropObj ? (cropObj[profile.language] || cropObj.en) : profile.crop;

  const current = weatherData?.current;

  return (
    <div className="dashboard-content">
      {/* 1. Personalized Farmer Hero Greeting */}
      <div className="hero-greeting-banner">
        <div className="greeting-text-wrap">
          <h1 className="greeting-title">{greeting}</h1>
          <p className="greeting-tagline">{t.tagline}</p>
        </div>

        {/* Quick Farm & Crop Details Card */}
        <div className="hero-farm-summary">
          <div className="farm-info-pill">
            <Sprout size={18} color="#16a34a" />
            <div className="pill-text">
              <span className="pill-label">{t.cropCardTitle}</span>
              <strong className="pill-value">{cropName}</strong>
            </div>
          </div>

          <div className="farm-info-pill">
            <MapPin size={18} color="#0284c7" />
            <div className="pill-text">
              <span className="pill-label">{t.locationCardTitle}</span>
              <strong className="pill-value">{profile.locationName}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Weather & Alert Overview Bar */}
      {alerts && alerts.length > 0 && (
        <div className="dashboard-alert-banner" onClick={() => setActiveTab('weather')}>
          <AlertTriangle size={22} className="alert-pulse-icon" />
          <div className="banner-text">
            <strong>{alerts[0].title}</strong>
            <p>{alerts[0].message}</p>
          </div>
          <ArrowRight size={18} className="banner-arrow" />
        </div>
      )}

      {/* 3. Quick Weather Snapshot Widget */}
      {current && (
        <div className="weather-snapshot-widget" onClick={() => setActiveTab('weather')}>
          <div className="snapshot-left">
            <span className="snapshot-temp">{Math.round(current.temperature_2m)}°C</span>
            <span className="snapshot-condition">
              {getWeatherDescription(current.weather_code, profile.language)}
            </span>
          </div>
          <div className="snapshot-right">
            <div className="snapshot-stat">
              <Droplets size={16} color="#0284c7" />
              <span>{current.relative_humidity_2m}% {t.humidity}</span>
            </div>
            <div className="snapshot-stat">
              <Wind size={16} color="#64748b" />
              <span>{current.wind_speed_10m} km/h {t.wind}</span>
            </div>
          </div>
        </div>
      )}

      {/* 4. Core Feature Action Grid (Mobile-friendly Large Touch Targets) */}
      <div className="feature-cards-grid">
        {/* Weather Forecast & Alerts */}
        <div className="action-card" onClick={() => setActiveTab('weather')}>
          <div className="card-icon-wrap bg-sky-light">
            <CloudSun size={28} color="#0284c7" />
          </div>
          <div className="card-content">
            <h3 className="card-title">{t.tabWeather}</h3>
            <p className="card-desc">
              {profile.language === 'te'
                ? 'మీ పొలం యొక్క 7 రోజుల వర్షం మరియు ఉష్ణోగ్రత సూచన.'
                : profile.language === 'hi'
                ? 'अपने खेत के 7-दिवसीय वर्षा और तापमान पूर्वानुमान देखें।'
                : 'Accurate 7-day farm forecast and weather alerts.'}
            </p>
          </div>
        </div>

        {/* Farm Tasks & Reminders */}
        <div className="action-card" onClick={() => setActiveTab('tasks')}>
          <div className="card-icon-wrap bg-amber-light">
            <CheckSquare size={28} color="#d97706" />
          </div>
          <div className="card-content">
            <h3 className="card-title">{t.tabTasks}</h3>
            <p className="card-desc">
              {profile.language === 'te'
                ? 'రోజువారీ వ్యవసాయ పనుల జాబితా మరియు నిర్వహణ.'
                : profile.language === 'hi'
                ? 'दैनिक कृषि कार्यों की सूची एवं अनुस्मारक।'
                : 'Organize and mark daily agricultural field activities.'}
            </p>
          </div>
        </div>

        {/* Profit Calculator */}
        <div className="action-card" onClick={() => setActiveTab('calc')}>
          <div className="card-icon-wrap bg-teal-light">
            <Calculator size={28} color="#0f766e" />
          </div>
          <div className="card-content">
            <h3 className="card-title">{t.tabCalculator}</h3>
            <p className="card-desc">
              {profile.language === 'te'
                ? 'దిగుబడి, ఖర్చులు మరియు మార్కెట్ ధర ఆధారంగా లాభం లెక్కించండి.'
                : profile.language === 'hi'
                ? 'लागत, उत्पादन और भाव के आधार पर शुद्ध लाभ का अनुमान।'
                : 'Estimate gross revenue, input expenses, and net returns.'}
            </p>
          </div>
        </div>

        {/* Soil Health */}
        <div className="action-card" onClick={() => setActiveTab('soil')}>
          <div className="card-icon-wrap bg-lime-light">
            <Layers size={28} color="#4d7c0f" />
          </div>
          <div className="card-content">
            <h3 className="card-title">{t.tabSoil}</h3>
            <p className="card-desc">
              {profile.language === 'te'
                ? 'భూసార పరీక్ష pH మరియు NPK విలువల విశ్లేషణ.'
                : profile.language === 'hi'
                ? 'मृदा स्वास्थ्य कार्ड pH और पोषक तत्वों का विश्लेषण।'
                : 'Understand soil test card values with honest guidelines.'}
            </p>
          </div>
        </div>

        {/* Market Rates */}
        <div className="action-card" onClick={() => setActiveTab('market')}>
          <div className="card-icon-wrap bg-indigo-light">
            <ShoppingBag size={28} color="#4338ca" />
          </div>
          <div className="card-content">
            <h3 className="card-title">{t.tabMarket}</h3>
            <p className="card-desc">
              {profile.language === 'te'
                ? 'మండి మార్కెట్ బెంచ్‌మార్క్ ధరలు మరియు స్థానిక నమోదు.'
                : profile.language === 'hi'
                ? 'मंडी भाव और स्थानीय दरों का विवरण।'
                : 'Transparent APMC mandi benchmarks and local price logs.'}
            </p>
          </div>
        </div>

        {/* Government Schemes & Subsidies */}
        <div className="action-card" onClick={() => setActiveTab('schemes')}>
          <div className="card-icon-wrap" style={{ background: '#ede9fe' }}>
            <Shield size={28} color="#7c3aed" />
          </div>
          <div className="card-content">
            <h3 className="card-title">{t.tabSchemes}</h3>
            <p className="card-desc">
              {profile.language === 'te'
                ? 'కేంద్ర, రాష్ట్ర వ్యవసాయ పథకాలు, సబ్సిడీలు మరియు అర్హత వివరాలు.'
                : profile.language === 'hi'
                ? 'केंद्रीय व राज्य कृषि योजनाएं, सब्सिडी और पात्रता विवरण।'
                : 'Central & State agricultural schemes, subsidies, and eligibility.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
