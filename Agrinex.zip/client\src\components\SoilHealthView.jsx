import React, { useState } from 'react';
import { TRANSLATIONS } from '../translations';
import { Layers, AlertCircle, CheckCircle, Info } from 'lucide-react';

export default function SoilHealthView({ profile }) {
  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;

  const [ph, setPh] = useState('6.8');
  const [nitrogen, setNitrogen] = useState('medium'); // low, medium, high
  const [phosphorus, setPhosphorus] = useState('medium');
  const [potassium, setPotassium] = useState('high');
  const [analysis, setAnalysis] = useState(null);

  const handleAnalyzeSoil = () => {
    const phVal = parseFloat(ph);
    let phStatus = 'neutral';
    let phNote = '';

    if (phVal < 6.0) {
      phStatus = 'acidic';
      phNote = profile.language === 'te' 
        ? 'నేల ఆమ్ల గుణం (Acidic) కలిగి ఉంది. వ్యవసాయ నిపుణుల సూచన మేరకు సున్నం (Lime) వాడకం పరిశీలించండి.'
        : profile.language === 'hi'
        ? 'मिट्टी अम्लीय है। कृषि अधिकारी की सलाह पर चूना (Lime) का प्रयोग विचारणीय है।'
        : 'Soil is acidic (pH < 6.0). Consider agricultural lime treatment after expert soil consultation.';
    } else if (phVal > 7.5) {
      phStatus = 'alkaline';
      phNote = profile.language === 'te'
        ? 'నేల క్షార గుణం (Alkaline) కలిగి ఉంది. జిప్సం లేదా సేంద్రియ ఎరువుల వాడకం మేలు చేస్తుంది.'
        : profile.language === 'hi'
        ? 'मिट्टी क्षारीय है। जिप्सम या जैविक कम्पोस्ट खाद का प्रयोग लाभदायक रहेगा।'
        : 'Soil is alkaline (pH > 7.5). Organic manure and gypsum can help improve soil structure.';
    } else {
      phStatus = 'optimal';
      phNote = profile.language === 'te'
        ? 'నేల pH చాలా అనుకూలంగా ఉంది (6.0 - 7.5). పంటలకు పోషకాలు సులభంగా అందుతాయి.'
        : profile.language === 'hi'
        ? 'मिट्टी का pH अधिकांश फसलों के लिए उत्तम (6.0 - 7.5) है।'
        : 'Soil pH is in the optimal range (6.0 - 7.5) for nutrient uptake.';
    }

    setAnalysis({
      phStatus,
      phNote,
      nAdvice: nitrogen === 'low' 
        ? (profile.language === 'te' ? 'నత్రజని తక్కువగా ఉంది. సేంద్రియ ఎరువులు లేదా సమతుల్య నత్రజని వేయండి.' : 'Nitrogen is low. Supplement with organic compost or recommended split doses.')
        : (profile.language === 'te' ? 'నత్రజని సరిపడా ఉంది.' : 'Nitrogen level is adequate.'),
      pAdvice: phosphorus === 'low'
        ? (profile.language === 'te' ? 'భాస్వరం లోపం ఉంది. సింగిల్ సూపర్ ఫాస్ఫేట్ (SSP) లేదా డీఏపీ నిపుణుల సలహాతో వేయండి.' : 'Phosphorus is low. Consider SSP application based on crop guide.')
        : (profile.language === 'te' ? 'భాస్వరం సాధారణ స్థాయిలో ఉంది.' : 'Phosphorus level is satisfactory.'),
      kAdvice: potassium === 'low'
        ? (profile.language === 'te' ? 'పొటాష్ లోపం ఉంది. పంట నాణ్యత మరియు రోగనిరోధకత కోసం మ్యూరేట్ ఆఫ్ పొటాష్ (MOP) అవసరం.' : 'Potash is low. Potash is essential for crop pest resistance and grain filling.')
        : (profile.language === 'te' ? 'పొటాషియం పుష్కలంగా ఉంది.' : 'Potassium level is well maintained.')
    });
  };

  return (
    <div className="soil-container">
      <div className="soil-header">
        <div className="soil-title-group">
          <Layers size={26} color="#16a34a" />
          <div>
            <h2 className="title-text">{t.soilTitle}</h2>
            <p className="subtitle-text">{t.soilSubtitle}</p>
          </div>
        </div>
      </div>

      {/* Explicit Disclaimer on camera limits vs lab testing */}
      <div className="soil-disclaimer-card">
        <AlertCircle size={20} color="#b45309" />
        <p>{t.soilDisclaimer}</p>
      </div>

      <div className="soil-form-card">
        <div className="soil-field">
          <label className="field-label">{t.soilPH} (3.0 - 10.0)</label>
          <input
            type="number"
            step="0.1"
            className="soil-text-input"
            value={ph}
            onChange={(e) => setPh(e.target.value)}
          />
        </div>

        <div className="npk-row">
          <div className="soil-field">
            <label className="field-label">{t.nitrogen}</label>
            <select className="soil-select" value={nitrogen} onChange={(e) => setNitrogen(e.target.value)}>
              <option value="low">Low (తక్కువ / कम)</option>
              <option value="medium">Medium (మధ్యస్థం / मध्यम)</option>
              <option value="high">High (ఎక్కువ / अधिक)</option>
            </select>
          </div>

          <div className="soil-field">
            <label className="field-label">{t.phosphorus}</label>
            <select className="soil-select" value={phosphorus} onChange={(e) => setPhosphorus(e.target.value)}>
              <option value="low">Low (తక్కువ / कम)</option>
              <option value="medium">Medium (మధ్యస్థం / मध्यम)</option>
              <option value="high">High (ఎక్కువ / अधिक)</option>
            </select>
          </div>

          <div className="soil-field">
            <label className="field-label">{t.potassium}</label>
            <select className="soil-select" value={potassium} onChange={(e) => setPotassium(e.target.value)}>
              <option value="low">Low (తక్కువ / कम)</option>
              <option value="medium">Medium (మధ్యస్థం / मध्यम)</option>
              <option value="high">High (ఎక్కువ / अधिक)</option>
            </select>
          </div>
        </div>

        <button type="button" className="btn-primary" onClick={handleAnalyzeSoil} style={{ marginTop: '14px' }}>
          {t.interpretSoil}
        </button>
      </div>

      {analysis && (
        <div className="soil-results-card">
          <div className="soil-result-heading">
            <CheckCircle size={22} color="#15803d" />
            <span>{profile.language === 'te' ? 'నేల విశ్లేషణ ఫలితాలు' : profile.language === 'hi' ? 'मृदा विश्लेषण परिणाम' : 'Soil Health Recommendations'}</span>
          </div>

          <div className="soil-recommendation-item">
            <strong>pH Status:</strong> {analysis.phNote}
          </div>
          <div className="soil-recommendation-item">
            <strong>Nitrogen (N):</strong> {analysis.nAdvice}
          </div>
          <div className="soil-recommendation-item">
            <strong>Phosphorus (P):</strong> {analysis.pAdvice}
          </div>
          <div className="soil-recommendation-item">
            <strong>Potassium (K):</strong> {analysis.kAdvice}
          </div>
        </div>
      )}
    </div>
  );
}
