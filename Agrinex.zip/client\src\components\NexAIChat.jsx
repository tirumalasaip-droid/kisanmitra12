import React, { useState, useEffect, useRef } from 'react';
import { TRANSLATIONS, COMMON_CROPS } from '../translations';
import { 
  Bot, Send, Mic, MicOff, Volume2, Square, Sparkles, AlertCircle, RefreshCw, User, HelpCircle 
} from 'lucide-react';

export default function NexAIChat({ profile, weatherData }) {
  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;
  
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      sender: 'bot',
      text: profile.language === 'te'
        ? `నమస్కారం ${profile.name} గారు! నేను మీ సఖి (Sakhi) వ్యవసాయ సహాయకురాలిని. మీ ${profile.crop} పంట, తెగుళ్లు, ఎరువుల నిర్వహణ లేదా వాతావరణం గురించి ఏమైనా అడగండి.`
        : profile.language === 'hi'
        ? `नमस्ते ${profile.name} जी! मैं आपकी सखी (Sakhi) कृषि सहायक हूँ। अपनी ${profile.crop} फसल, कीट, पोषण या मौसम संबंधी किसी भी प्रश्न के लिए पूछें।`
        : `Namaste ${profile.name}! I am Sakhi, your smart farming companion. How can I assist you with your ${profile.crop} crop, soil, pests, or field operations today?`
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiConfigured, setAiConfigured] = useState(null);
  const [configMessage, setConfigMessage] = useState('');
  
  // Voice Speech Recognition & Synthesis states
  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  const recognitionRef = useRef(null);
  const messagesEndRef = useRef(null);

  // Check backend status on mount
  useEffect(() => {
    fetch('/api/status')
      .then(res => res.json())
      .then(data => {
        setAiConfigured(data.aiConfigured);
        if (!data.aiConfigured) {
          setConfigMessage(data.message);
        }
      })
      .catch(err => {
        console.warn('Backend status check failed:', err);
        setAiConfigured(false);
        setConfigMessage('Backend server is unreachable. Make sure "npm start" is running on port 5000.');
      });
  }, []);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  // Setup Web Speech API for voice input
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      
      // Select appropriate language code: te-IN, hi-IN, en-IN
      recognition.lang = profile.language === 'te' ? 'te-IN' : profile.language === 'hi' ? 'hi-IN' : 'en-IN';

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInput((prev) => (prev ? prev + ' ' + transcript : transcript));
        setIsListening(false);
      };

      recognition.onerror = (event) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setSpeechError(profile.language === 'te' ? 'మైక్రోఫోన్ అనుమతి తిరస్కరించబడింది.' : profile.language === 'hi' ? 'माइक्रोफ़ोन की अनुमति अस्वीकृत।' : 'Microphone permission denied.');
        } else {
          setSpeechError(profile.language === 'te' ? `వాయిస్ సమస్య: ${event.error}` : `Voice recognition error: ${event.error}`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }

    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, [profile.language]);

  // Toggle voice recognition
  const toggleVoiceInput = () => {
    setSpeechError('');
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSpeechError(t.speechNotSupported);
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.lang = profile.language === 'te' ? 'te-IN' : profile.language === 'hi' ? 'hi-IN' : 'en-IN';
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.error('Recognition start failed', err);
        setIsListening(false);
      }
    }
  };

  const audioPlayerRef = useRef(null);
  const [voices, setVoices] = useState([]);

  // Load and cache browser voices when ready (handles asynchronous voiceschanged)
  useEffect(() => {
    if (!('speechSynthesis' in window)) return;

    const updateVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      if (availableVoices && availableVoices.length > 0) {
        setVoices(availableVoices);
      }
    };

    updateVoices();
    window.speechSynthesis.addEventListener('voiceschanged', updateVoices);

    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', updateVoices);
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
    };
  }, []);

  // Detect script/language of specific message text
  const detectLanguage = (text) => {
    if (!text) return profile.language || 'en';
    // Telugu Unicode block: \u0C00-\u0C7F
    if (/[\u0C00-\u0C7F]/.test(text)) return 'te';
    // Devanagari (Hindi) Unicode block: \u0900-\u097F
    if (/[\u0900-\u097F]/.test(text)) return 'hi';
    return 'en';
  };

  // Clean markdown symbols (#, *, _, `, ~, >, bullets, URLs) for spoken audio
  const cleanTextForSpeech = (rawText) => {
    if (!rawText) return '';
    return rawText
      // Remove code blocks and inline code
      .replace(/```[\s\S]*?```/g, ' ')
      .replace(/`([^`]+)`/g, '$1')
      // Remove markdown links [text](url) -> text
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      // Remove headers (# Header)
      .replace(/^\s{0,3}#{1,6}\s+/gm, '')
      // Remove bullet points and numbered list markers (*, -, +, 1.)
      .replace(/^\s*[\*\-\+]\s+/gm, '')
      .replace(/^\s*\d+\.\s+/gm, '')
      // Remove markdown emphasis formatting (**bold**, *italic*, __bold__, _italic_, ~~strike~~)
      .replace(/(\*\*|__)(.*?)\1/g, '$2')
      .replace(/(\*|_)(.*?)\1/g, '$2')
      .replace(/~~(.*?)~~/g, '$1')
      // Remove blockquotes and horizontal rules
      .replace(/^\s*>\s+/gm, '')
      .replace(/^\s*[-*_]{3,}\s*$/gm, '')
      // Remove remaining stray markdown or punctuation artifacts
      .replace(/[#*_~`]/g, '')
      // Collapse excess whitespace and linebreaks
      .replace(/\s+/g, ' ')
      .trim();
  };

  // Speak message aloud using browser speech synthesis with server fallback for Telugu
  const handleSpeakText = (text) => {
    setSpeechError('');

    // If currently speaking, stop both browser and audio element
    if (isSpeaking) {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        audioPlayerRef.current.currentTime = 0;
      }
      setIsSpeaking(false);
      return;
    }

    const cleanedText = cleanTextForSpeech(text);
    if (!cleanedText) return;

    const detectedLang = detectLanguage(cleanedText);
    const speechLangTag = detectedLang === 'te' ? 'te-IN' : detectedLang === 'hi' ? 'hi-IN' : 'en-IN';

    // 1. Try finding a native browser voice for the detected language
    const currentVoices = voices.length > 0 ? voices : (('speechSynthesis' in window) ? window.speechSynthesis.getVoices() : []);
    const matchingVoice = currentVoices.find(v => {
      const vLang = (v.lang || '').toLowerCase().replace('_', '-');
      return vLang.startsWith(detectedLang) || (detectedLang === 'te' && (vLang.includes('telugu') || v.name.toLowerCase().includes('telugu')));
    });

    // 2. If matching browser voice exists or language is English, use Web Speech API
    if (('speechSynthesis' in window) && (matchingVoice || detectedLang === 'en')) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(cleanedText);
      utterance.lang = speechLangTag;
      utterance.rate = 0.95;

      if (matchingVoice) {
        utterance.voice = matchingVoice;
      } else if (detectedLang === 'en') {
        const enVoice = currentVoices.find(v => (v.lang || '').toLowerCase().startsWith('en'));
        if (enVoice) utterance.voice = enVoice;
      }

      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = (e) => {
        console.warn('SpeechSynthesis error:', e);
        setIsSpeaking(false);
        // If browser synthesis failed for Telugu, fallback to server TTS
        if (detectedLang === 'te') {
          playServerTTS(cleanedText, detectedLang);
        }
      };

      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
      return;
    }

    // 3. Fallback for Telugu (or when browser lacks native voice)
    playServerTTS(cleanedText, detectedLang);
  };

  // Play audio via backend streaming TTS proxy
  const playServerTTS = (cleanText, lang) => {
    try {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }

      const audioUrl = `/api/tts?text=${encodeURIComponent(cleanText)}&lang=${lang}`;
      const audio = new Audio(audioUrl);
      audioPlayerRef.current = audio;

      setIsSpeaking(true);

      audio.onended = () => {
        setIsSpeaking(false);
      };

      audio.onerror = (e) => {
        console.warn('Server TTS playback error:', e);
        setIsSpeaking(false);
        setSpeechError(
          profile.language === 'te'
            ? 'ఈ పరికరంలో తెలుగు ఆడియో అందుబాటులో లేదు.'
            : 'Audio playback unavailable for this language on this device.'
        );
      };

      audio.play().catch(err => {
        console.warn('Audio play was prevented or failed:', err);
        setIsSpeaking(false);
      });
    } catch (err) {
      console.error('TTS error:', err);
      setIsSpeaking(false);
    }
  };

  // Send question to backend AI
  const handleSendMessage = async (queryText) => {
    const textToSend = queryText || input;
    if (!textToSend || !textToSend.trim() || loading) return;

    const userMessage = { id: Date.now().toString(), sender: 'user', text: textToSend.trim() };
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInput('');
    setLoading(true);

    try {
      const cropObj = COMMON_CROPS.find(c => c.id === profile.crop);
      const cropDisplayName = cropObj ? (cropObj[profile.language] || cropObj.en) : profile.crop;

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend.trim(),
          history: updatedMessages.map(m => ({ sender: m.sender, text: m.text })),
          language: profile.language,
          farmerName: profile.name,
          crop: cropDisplayName,
          stage: profile.cropStage,
          locationName: profile.locationName,
          weatherContext: weatherData?.current ? {
            temperature: weatherData.current.temperature_2m,
            rain: weatherData.current.rain,
            humidity: weatherData.current.relative_humidity_2m
          } : null
        })
      });

      const data = await res.json();

      if (!res.ok) {
        if (data.error === 'AI_NOT_CONFIGURED') {
          setAiConfigured(false);
          setConfigMessage(data.message);
          setMessages(prev => [
            ...prev,
            {
              id: (Date.now() + 1).toString(),
              sender: 'bot',
              isError: true,
              text: profile.language === 'te'
                ? `నెక్స్ AI సెట్టింగ్ గమనిక: AI సేవను ప్రారంభించడానికి backend/.env ఫైల్‌లో ఉచిత GEMINI_API_KEY ను చేర్చండి. మీరు aistudio.google.com నుండి ఉచిత కీని పొందవచ్చు.`
                : profile.language === 'hi'
                ? `नेक्स AI सूचना: लाइव AI संवाद के लिए backend/.env में GEMINI_API_KEY सेट करें। इसे https://aistudio.google.com/ से मुफ्त में प्राप्त किया जा सकता है।`
                : `Nex AI Notice: Live AI features require a free GEMINI_API_KEY in the backend .env file. Obtain one at https://aistudio.google.com/.`
            }
          ]);
        } else {
          throw new Error(data.message || 'Error occurred while contacting Nex AI.');
        }
      } else {
        setMessages(prev => [
          ...prev,
          {
            id: (Date.now() + 1).toString(),
            sender: 'bot',
            text: data.reply
          }
        ]);
      }
    } catch (err) {
      console.error('Nex AI Error:', err);
      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'bot',
          isError: true,
          text: profile.language === 'te'
            ? `క్షమించండి, సర్వర్ సమస్య వచ్చింది: ${err.message}`
            : profile.language === 'hi'
            ? `क्षमा करें, सर्वर त्रुटि: ${err.message}`
            : `Sorry, unable to get response: ${err.message}`
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  // 10 Suggested Questions defined in translations
  const suggestedQuestions = [
    { key: 'q_weather', text: t.q_weather },
    { key: 'q_suitable_crops', text: t.q_suitable_crops },
    { key: 'q_planting_month', text: t.q_planting_month },
    { key: 'q_pest_problem', text: t.q_pest_problem },
    { key: 'q_examine_photo', text: t.q_examine_photo },
    { key: 'q_heat_protection', text: t.q_heat_protection },
    { key: 'q_irrigation_plan', text: t.q_irrigation_plan },
    { key: 'q_nutrients', text: t.q_nutrients },
    { key: 'q_prioritize_tasks', text: t.q_prioritize_tasks },
    { key: 'q_profit_estimate', text: t.q_profit_estimate }
  ];

  return (
    <div className="nexai-container">
      {/* AI Header */}
      <div className="nexai-header">
        <div className="nexai-title-wrap">
          <div className="bot-avatar">
            <Bot size={24} color="#16a34a" />
          </div>
          <div>
            <h2 className="title-text">{t.nexAITitle}</h2>
            <p className="subtitle-text">{t.nexAISubtitle}</p>
          </div>
        </div>

        <div className="status-indicator-badge">
          <span className={`status-dot ${aiConfigured ? 'dot-active' : 'dot-pending'}`} />
          <span className="status-label">
            {aiConfigured ? 'Gemini 2.5 Active' : 'API Key Required'}
          </span>
        </div>
      </div>

      {/* AI Not Configured Alert Banner */}
      {aiConfigured === false && (
        <div className="ai-warning-banner">
          <AlertCircle size={20} className="warning-icon" />
          <div className="warning-text">
            <strong>{profile.language === 'te' ? 'AI కీ అవసరం:' : profile.language === 'hi' ? 'AI कुंजी आवश्यक:' : 'Setup Notice:'}</strong> {configMessage || t.aiUnconfiguredNotice}
          </div>
        </div>
      )}

      {/* Suggested Questions Carousel / Grid */}
      <div className="suggested-questions-section">
        <div className="suggested-heading">
          <Sparkles size={16} color="#15803d" />
          <span>{t.suggestedQuestionsTitle}</span>
        </div>
        <div className="suggested-chips-scroll">
          {suggestedQuestions.map((q) => (
            <button
              key={q.key}
              type="button"
              className="chip-btn"
              onClick={() => handleSendMessage(q.text)}
              disabled={loading}
            >
              {q.text}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="chat-messages-scroll">
        {messages.map((m) => (
          <div key={m.id} className={`chat-bubble-row ${m.sender === 'user' ? 'user-row' : 'bot-row'}`}>
            {m.sender === 'bot' && (
              <div className="message-avatar bot">
                <Bot size={18} />
              </div>
            )}
            <div className={`message-bubble ${m.sender === 'user' ? 'user-bubble' : 'bot-bubble'} ${m.isError ? 'error-bubble' : ''}`}>
              <div className="message-content-text" style={{ whiteSpace: 'pre-wrap' }}>
                {m.text}
              </div>

              {/* Bot Voice Speaker Button */}
              {m.sender === 'bot' && !m.isError && (
                <div className="message-toolbar">
                  <button
                    type="button"
                    className="speak-btn"
                    onClick={() => handleSpeakText(m.text)}
                    title={isSpeaking ? t.stopSpeaking : t.speak}
                  >
                    {isSpeaking ? (
                      <>
                        <Square size={14} color="#dc2626" />
                        <span>{t.stopSpeaking}</span>
                      </>
                    ) : (
                      <>
                        <Volume2 size={14} />
                        <span>{t.speak}</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
            {m.sender === 'user' && (
              <div className="message-avatar user">
                <User size={18} />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="chat-bubble-row bot-row">
            <div className="message-avatar bot">
              <Bot size={18} />
            </div>
            <div className="message-bubble bot-bubble typing-bubble">
              <div className="typing-dots">
                <span /><span /><span />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Speech Recognition Error Notice */}
      {speechError && (
        <div className="speech-error-bar">
          <span>⚠️ {speechError}</span>
          <button type="button" onClick={() => setSpeechError('')}>×</button>
        </div>
      )}

      {/* Voice Transcript / Active Listening Bar */}
      {isListening && (
        <div className="listening-bar">
          <div className="pulsing-mic">
            <Mic size={18} color="#ffffff" />
          </div>
          <span>{t.listening}</span>
          <button type="button" className="stop-mic-btn" onClick={toggleVoiceInput}>
            Done
          </button>
        </div>
      )}

      {/* Chat Input Bar */}
      <form 
        className="chat-input-bar"
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
      >
        {/* Voice Input Mic Button */}
        <button
          type="button"
          className={`mic-button ${isListening ? 'listening' : ''}`}
          onClick={toggleVoiceInput}
          title={isListening ? t.stopSpeaking : 'Start Voice Input'}
        >
          {isListening ? <MicOff size={22} color="#dc2626" /> : <Mic size={22} color="#15803d" />}
        </button>

        {/* Input Text Box */}
        <input
          type="text"
          className="chat-text-input"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={t.askInputPlaceholder}
          disabled={loading}
        />

        {/* Send Button */}
        <button
          type="submit"
          className="chat-send-btn"
          disabled={!input.trim() || loading}
          title={t.send}
        >
          <Send size={18} />
        </button>
      </form>
    </div>
  );
}
