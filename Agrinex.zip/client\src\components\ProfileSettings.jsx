import React, { useState } from 'react';
import { TRANSLATIONS } from '../translations';
import { User, Globe, Sprout, MapPin, RefreshCcw, Save } from 'lucide-react';
import LocationPickerMap from './LocationPickerMap';
import { COMMON_CROPS } from '../translations';

export default function ProfileSettings({ profile, onUpdateProfile, onResetAll }) {
  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;

  const [name, setName] = useState(profile.name || '');
  const [language, setLanguage] = useState(profile.language || 'te');
  const [crop, setCrop] = useState(profile.crop || 'paddy');
  const [cropStage, setCropStage] = useState(profile.cropStage || 'growing');
  const [locationName, setLocationName] = useState(profile.locationName || '');
  const [coords, setCoords] = useState(profile.coords || { lat: 16.3067, lng: 80.4365 });
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e) => {
    e.preventDefault();
    const updated = {
      ...profile,
      name: name.trim() || profile.name,
      language,
      crop,
      cropStage,
      locationName: locationName.trim() || profile.locationName,
      coords
    };
    onUpdateProfile(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="settings-container">
      <div className="settings-header">
        <h2 className="title-text">{t.settingsTitle}</h2>
      </div>

      <form onSubmit={handleSave} className="settings-card">
        {/* Language Selection */}
        <div className="settings-field">
          <label className="field-label">
            <Globe size={18} />
            <span>{t.changeLang}</span>
          </label>
          <div className="lang-switcher-row">
            <button
              type="button"
              className={`lang-tab ${language === 'te' ? 'active' : ''}`}
              onClick={() => setLanguage('te')}
            >
              తెలుగు (Telugu)
            </button>
            <button
              type="button"
              className={`lang-tab ${language === 'hi' ? 'active' : ''}`}
              onClick={() => setLanguage('hi')}
            >
              हिन्दी (Hindi)
            </button>
            <button
              type="button"
              className={`lang-tab ${language === 'en' ? 'active' : ''}`}
              onClick={() => setLanguage('en')}
            >
              English
            </button>
          </div>
        </div>

        {/* Farmer Name */}
        <div className="settings-field">
          <label className="field-label">
            <User size={18} />
            <span>{t.enterName}</span>
          </label>
          <input
            type="text"
            className="settings-input"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        {/* Crop Selection */}
        <div className="settings-field">
          <label className="field-label">
            <Sprout size={18} />
            <span>{t.changeCrop}</span>
          </label>
          <select className="settings-select" value={crop} onChange={(e) => setCrop(e.target.value)}>
            {COMMON_CROPS.map(c => (
              <option key={c.id} value={c.id}>
                {language === 'te' ? c.te : language === 'hi' ? c.hi : c.en}
              </option>
            ))}
          </select>
        </div>

        {/* Crop Stage */}
        <div className="settings-field">
          <label className="field-label">
            <Sprout size={18} />
            <span>{t.changeStage}</span>
          </label>
          <select className="settings-select" value={cropStage} onChange={(e) => setCropStage(e.target.value)}>
            <option value="planned">🌱 {t.stagePlanned}</option>
            <option value="planted">🌿 {t.stagePlanted}</option>
            <option value="growing">🌾 {t.stageGrowing}</option>
          </select>
        </div>

        {/* Farm Location */}
        <div className="settings-field">
          <label className="field-label">
            <MapPin size={18} />
            <span>{t.changeLocation}</span>
          </label>
          <input
            type="text"
            className="settings-input"
            value={locationName}
            onChange={(e) => setLocationName(e.target.value)}
          />
        </div>

        <div style={{ marginTop: '10px' }}>
          <label className="field-label" style={{ marginBottom: '8px', display: 'block' }}>
            🗺️ {t.orPickOnMap}
          </label>
          <LocationPickerMap
            lat={coords.lat}
            lng={coords.lng}
            onSelectLocation={(lat, lng) => setCoords({ lat, lng })}
            height="200px"
          />
        </div>

        {/* Save button */}
        <div style={{ marginTop: '20px', display: 'flex', gap: '12px', alignItems: 'center' }}>
          <button type="submit" className="btn-primary" style={{ padding: '12px 24px' }}>
            <Save size={18} />
            <span>{t.save}</span>
          </button>
          {savedSuccess && (
            <span style={{ color: '#16a34a', fontWeight: '600' }}>✓ Saved successfully!</span>
          )}
        </div>
      </form>

      {/* Reset Data Option */}
      <div className="reset-section">
        <button
          type="button"
          className="reset-btn"
          onClick={() => {
            if (window.confirm(t.resetConfirm)) {
              onResetAll();
            }
          }}
        >
          <RefreshCcw size={16} />
          <span>{t.resetData}</span>
        </button>
      </div>
    </div>
  );
}
