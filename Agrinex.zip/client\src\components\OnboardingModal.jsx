import React, { useState } from 'react';
import { TRANSLATIONS, COMMON_CROPS } from '../translations';
import LocationPickerMap from './LocationPickerMap';
import { Globe, MapPin, Navigation, Sprout, ArrowRight, ArrowLeft, CheckCircle2 } from 'lucide-react';

export default function OnboardingModal({ onComplete }) {
  const [step, setStep] = useState(1);
  const [language, setLanguage] = useState('te'); // Telugu, Hindi, or English
  const [name, setName] = useState('');
  const [crop, setCrop] = useState('paddy');
  const [cropStage, setCropStage] = useState('growing');
  const [locationName, setLocationName] = useState('Guntur, Andhra Pradesh');
  const [coords, setCoords] = useState({ lat: 16.3067, lng: 80.4365 });
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState('');

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  // Step 1: Language selection
  const handleSelectLanguage = (langKey) => {
    setLanguage(langKey);
    setStep(2);
  };

  // GPS Current Location detection
  const handleGetDeviceLocation = () => {
    if (!navigator.geolocation) {
      setGpsError(language === 'te' ? 'మీ పరికరంలో లొకేషన్ సదుపాయం లేదు.' : language === 'hi' ? 'स्थान सुविधा समर्थित नहीं है।' : 'Geolocation not supported by browser.');
      return;
    }
    setGpsLoading(true);
    setGpsError('');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsLoading(false);
        const { latitude, longitude } = pos.coords;
        setCoords({ lat: latitude, lng: longitude });
        setLocationName(`Farm Location (${latitude.toFixed(2)}, ${longitude.toFixed(2)})`);
      },
      (err) => {
        setGpsLoading(false);
        console.warn('GPS Error:', err.message);
        setGpsError(language === 'te' ? 'లొకేషన్ అనుమతి లభించలేదు. దయచేసి మ్యాప్‌లో ఎంచుకోండి.' : language === 'hi' ? 'स्थान अनुमति नहीं मिली। कृपया मानचित्र पर चुनें।' : 'Location permission denied. Please choose on map.');
      },
      { timeout: 8000 }
    );
  };

  // Final submission of onboarding data
  const handleFinish = () => {
    const profile = {
      language,
      name: name.trim() || (language === 'te' ? 'రైతు మిత్రుడు' : language === 'hi' ? 'किसान भाई' : 'Farmer Friend'),
      crop,
      cropStage,
      locationName: locationName.trim() || 'Farm',
      coords,
      onboardingComplete: true
    };
    localStorage.setItem('agrinex_profile', JSON.stringify(profile));
    onComplete(profile);
  };

  return (
    <div className="onboarding-overlay">
      <div className="onboarding-card">
        {/* Step Indicator Header */}
        <div className="onboarding-header">
          <div className="brand-badge">
            <span className="brand-leaf">🌱</span>
            <span className="brand-title">KisanMitra</span>
          </div>
          <div className="steps-dots">
            <span className={`dot ${step >= 1 ? 'active' : ''}`} />
            <span className={`dot ${step >= 2 ? 'active' : ''}`} />
            <span className={`dot ${step >= 3 ? 'active' : ''}`} />
            <span className={`dot ${step >= 4 ? 'active' : ''}`} />
          </div>
        </div>

        {/* STEP 1: LANGUAGE SELECTION */}
        {step === 1 && (
          <div className="step-content">
            <h2 className="step-title">Select Your Language / మీ భాషను ఎంచుకోండి / भाषा चुनें</h2>
            <p className="step-subtitle">Choose how you want to experience KisanMitra:</p>
            
            <div className="lang-options-grid">
              <button 
                type="button" 
                className={`lang-choice-card ${language === 'te' ? 'selected' : ''}`}
                onClick={() => handleSelectLanguage('te')}
              >
                <div className="lang-script">తెలుగు</div>
                <div className="lang-english">Telugu</div>
                <div className="lang-badge">ఆంధ్రప్రదేశ్ & తెలంగాణ</div>
              </button>

              <button 
                type="button" 
                className={`lang-choice-card ${language === 'hi' ? 'selected' : ''}`}
                onClick={() => handleSelectLanguage('hi')}
              >
                <div className="lang-script">हिन्दी</div>
                <div className="lang-english">Hindi</div>
                <div className="lang-badge">भारत के सभी किसान</div>
              </button>

              <button 
                type="button" 
                className={`lang-choice-card ${language === 'en' ? 'selected' : ''}`}
                onClick={() => handleSelectLanguage('en')}
              >
                <div className="lang-script">English</div>
                <div className="lang-english">Indian English</div>
                <div className="lang-badge">Simple & Clear</div>
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: FARMER'S NAME */}
        {step === 2 && (
          <div className="step-content">
            <h2 className="step-title">{t.enterName}</h2>
            <p className="step-subtitle">
              {language === 'te' 
                ? 'మీ పేరు నమోదు చేయండి. మేము మిమ్మల్ని సగౌరవంగా పిలుస్తాము.' 
                : language === 'hi'
                ? 'अपना नाम दर्ज करें ताकि हम आपसे आदरपूर्वक संवाद कर सकें।'
                : 'Enter your name so we can personalize your agricultural advice.'}
            </p>

            <div className="input-field-group">
              <input
                type="text"
                className="text-input-large"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t.namePlaceholder}
                autoFocus
              />
            </div>

            {name.trim() && (
              <div className="name-preview-chip">
                <span>🌾 {language === 'te' ? `నమస్కారం ${name} గారు!` : language === 'hi' ? `नमस्ते ${name} जी!` : `Namaste ${name}!`}</span>
              </div>
            )}

            <div className="step-action-bar">
              <button type="button" className="btn-secondary" onClick={() => setStep(1)}>
                <ArrowLeft size={18} /> {t.back}
              </button>
              <button type="button" className="btn-primary" onClick={() => setStep(3)}>
                {t.next} <ArrowRight size={18} />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: CROP & GROWTH STAGE */}
        {step === 3 && (
          <div className="step-content">
            <h2 className="step-title">{t.selectCrop}</h2>
            <p className="step-subtitle">
              {language === 'te' 
                ? 'మీరు సాగు చేస్తున్న పంటను ఎంచుకోండి:' 
                : language === 'hi' 
                ? 'अपनी मुख्य फसल का चयन करें:' 
                : 'Choose your active or planned farm crop:'}
            </p>

            <div className="crop-selector-grid">
              {COMMON_CROPS.map((c) => {
                const label = language === 'te' ? c.te : language === 'hi' ? c.hi : c.en;
                return (
                  <button
                    key={c.id}
                    type="button"
                    className={`crop-btn ${crop === c.id ? 'active' : ''}`}
                    onClick={() => setCrop(c.id)}
                  >
                    <Sprout size={18} />
                    <span>{label}</span>
                  </button>
                );
              })}
            </div>

            <div className="stage-section" style={{ marginTop: '20px' }}>
              <label className="section-label">{t.cropStageTitle}</label>
              <div className="stage-radio-group">
                <button
                  type="button"
                  className={`stage-pill ${cropStage === 'planned' ? 'active' : ''}`}
                  onClick={() => setCropStage('planned')}
                >
                  🌱 {t.stagePlanned}
                </button>
                <button
                  type="button"
                  className={`stage-pill ${cropStage === 'planted' ? 'active' : ''}`}
                  onClick={() => setCropStage('planted')}
                >
                  🌿 {t.stagePlanted}
                </button>
                <button
                  type="button"
                  className={`stage-pill ${cropStage === 'growing' ? 'active' : ''}`}
                  onClick={() => setCropStage('growing')}
                >
                  🌾 {t.stageGrowing}
                </button>
              </div>
            </div>

            <div className="step-action-bar">
              <button type="button" className="btn-secondary" onClick={() => setStep(2)}>
                <ArrowLeft size={18} /> {t.back}
              </button>
              <button type="button" className="btn-primary" onClick={() => setStep(4)}>
                {t.next} <ArrowRight size={18} />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: FARM LOCATION & MAP */}
        {step === 4 && (
          <div className="step-content">
            <h2 className="step-title">{t.farmLocationTitle}</h2>
            <p className="step-subtitle">{t.farmLocationDesc}</p>

            <div className="location-inputs">
              <div className="input-row">
                <input
                  type="text"
                  className="text-input"
                  value={locationName}
                  onChange={(e) => setLocationName(e.target.value)}
                  placeholder={t.locPlaceholder}
                />
                <button 
                  type="button" 
                  className="gps-btn" 
                  onClick={handleGetDeviceLocation}
                  disabled={gpsLoading}
                  title="Detect GPS"
                >
                  <Navigation size={18} className={gpsLoading ? 'spin' : ''} />
                  <span>{gpsLoading ? '...' : t.useCurrentLocation}</span>
                </button>
              </div>

              {gpsError && <p className="gps-err-msg">{gpsError}</p>}
            </div>

            {/* Map manual selection */}
            <div style={{ marginTop: '12px' }}>
              <label className="section-label" style={{ marginBottom: '6px', display: 'block' }}>
                🗺️ {t.orPickOnMap}
              </label>
              <LocationPickerMap
                lat={coords.lat}
                lng={coords.lng}
                onSelectLocation={(lat, lng) => setCoords({ lat, lng })}
                height="220px"
              />
            </div>

            <div className="step-action-bar" style={{ marginTop: '18px' }}>
              <button type="button" className="btn-secondary" onClick={() => setStep(3)}>
                <ArrowLeft size={18} /> {t.back}
              </button>
              <button type="button" className="btn-primary finish-btn" onClick={handleFinish}>
                <CheckCircle2 size={18} /> {t.completeOnboarding}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
