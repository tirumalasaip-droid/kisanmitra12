import React, { useState, useEffect } from 'react';
import './App.css';
import { TRANSLATIONS } from './translations';
import { fetchFarmWeather, generateDataBackedAlerts } from './weatherService';

// Components
import OnboardingModal from './components/OnboardingModal';
import MainDashboard from './components/MainDashboard';
import NexAIChat from './components/NexAIChat';
import CropPhotoAnalysis from './components/CropPhotoAnalysis';
import WeatherForecastView from './components/WeatherForecastView';
import FarmTasks from './components/FarmTasks';
import ProfitCalculator from './components/ProfitCalculator';
import SoilHealthView from './components/SoilHealthView';
import MarketPricesView from './components/MarketPricesView';
import GovernmentSchemesView from './components/GovernmentSchemesView';
import ProfileSettings from './components/ProfileSettings';

// Icons
import { 
  Home, Bot, Camera, ImagePlus, CloudSun, CheckSquare, Settings, Globe, Smartphone
} from 'lucide-react';

export default function App() {
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem('agrinex_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse profile', e);
      }
    }
    return null;
  });

  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobilePreview, setIsMobilePreview] = useState(() => {
    return localStorage.getItem('agrinex_mobile_preview') === 'true';
  });
  const [weatherData, setWeatherData] = useState(null);
  const [weatherAlerts, setWeatherAlerts] = useState([]);
  const [weatherLoading, setWeatherLoading] = useState(false);

  const toggleMobilePreview = () => {
    setIsMobilePreview((prev) => {
      const next = !prev;
      localStorage.setItem('agrinex_mobile_preview', String(next));
      return next;
    });
  };

  // Load weather whenever profile location changes
  useEffect(() => {
    if (profile && profile.coords) {
      loadWeather(profile.coords.lat, profile.coords.lng);
    }
  }, [profile?.coords?.lat, profile?.coords?.lng, profile?.language]);

  const loadWeather = async (lat, lng) => {
    setWeatherLoading(true);
    const res = await fetchFarmWeather(lat, lng);
    setWeatherLoading(false);

    if (res.success && res.data) {
      setWeatherData(res.data);
      const generatedAlerts = generateDataBackedAlerts(res.data, profile?.name, profile?.language || 'te');
      setWeatherAlerts(generatedAlerts);
    }
  };

  const handleUpdateProfile = (updated) => {
    setProfile(updated);
    localStorage.setItem('agrinex_profile', JSON.stringify(updated));
  };

  const handleResetAll = () => {
    localStorage.removeItem('agrinex_profile');
    localStorage.removeItem('agrinex_tasks');
    localStorage.removeItem('agrinex_market_rates');
    setProfile(null);
    setActiveTab('dashboard');
  };

  // If user hasn't completed onboarding, render onboarding flow
  if (!profile || !profile.onboardingComplete) {
    return (
      <div className="app-layout">
        <OnboardingModal onComplete={(newProf) => setProfile(newProf)} />
      </div>
    );
  }

  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;

  const appContent = (
    <div className={`app-layout ${isMobilePreview ? 'mobile-preview-device' : ''}`}>
      {/* Top Application Header */}
      <header className="app-topbar">
        <div className="brand-section" onClick={() => setActiveTab('dashboard')}>
          <div className="brand-logo-icon">🌱</div>
          <div>
            <h1 className="brand-title">KisanMitra</h1>
          </div>
        </div>

        <div className="topbar-actions">
          {/* Sakhi AI Assistant Icon Button */}
          <button
            type="button"
            className={`nav-settings-btn ${activeTab === 'ai' ? 'active' : ''}`}
            onClick={() => setActiveTab('ai')}
            title={t.tabNexAI || 'Sakhi'}
            aria-label="Sakhi AI Assistant"
          >
            <Bot size={20} color={activeTab === 'ai' ? '#15803d' : '#475569'} />
          </button>

          {/* Crop Disease Detection & Photo Upload Icon Button */}
          <button
            type="button"
            className={`nav-settings-btn ${activeTab === 'vision' ? 'active' : ''}`}
            onClick={() => setActiveTab('vision')}
            title={t.tabCropVision}
            aria-label="Crop Disease Detection"
          >
            <ImagePlus size={20} color={activeTab === 'vision' ? '#15803d' : '#475569'} />
          </button>

          {/* Quick Language Switcher */}
          <select 
            className="lang-pill-select"
            value={profile.language}
            onChange={(e) => handleUpdateProfile({ ...profile, language: e.target.value })}
          >
            <option value="te">తెలుగు</option>
            <option value="hi">हिन्दी</option>
            <option value="en">English</option>
          </select>

          {/* Mobile Preview Toggle Button */}
          <button
            type="button"
            className={`nav-settings-btn ${isMobilePreview ? 'active' : ''}`}
            onClick={toggleMobilePreview}
            title={isMobilePreview ? "Switch to Full Screen View" : "Switch to Mobile Device Preview (390px)"}
            aria-label="Toggle Mobile Preview"
            style={{
              background: isMobilePreview ? '#dcfce7' : 'transparent',
              color: isMobilePreview ? '#15803d' : '#64748b'
            }}
          >
            <Smartphone size={20} />
          </button>

          {/* Profile / Settings Button */}
          <button 
            type="button" 
            className="nav-settings-btn"
            onClick={() => setActiveTab('settings')}
            title={t.tabSettings}
          >
            <Settings size={20} />
          </button>
        </div>
      </header>

      {/* Main Screen Content Body */}
      <main className="main-view-container">
        {activeTab === 'dashboard' && (
          <MainDashboard 
            profile={profile} 
            weatherData={weatherData} 
            alerts={weatherAlerts}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'ai' && (
          <NexAIChat 
            profile={profile} 
            weatherData={weatherData} 
          />
        )}

        {activeTab === 'vision' && (
          <CropPhotoAnalysis 
            profile={profile} 
          />
        )}

        {activeTab === 'weather' && (
          <WeatherForecastView 
            profile={profile} 
            weatherData={weatherData} 
            alerts={weatherAlerts}
            loading={weatherLoading}
            onRefresh={() => loadWeather(profile.coords.lat, profile.coords.lng)}
          />
        )}

        {activeTab === 'tasks' && (
          <FarmTasks 
            profile={profile} 
          />
        )}

        {activeTab === 'calc' && (
          <ProfitCalculator 
            profile={profile} 
          />
        )}

        {activeTab === 'soil' && (
          <SoilHealthView 
            profile={profile} 
          />
        )}

        {activeTab === 'market' && (
          <MarketPricesView 
            profile={profile} 
          />
        )}

        {activeTab === 'schemes' && (
          <GovernmentSchemesView 
            profile={profile} 
          />
        )}

        {activeTab === 'settings' && (
          <ProfileSettings 
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            onResetAll={handleResetAll}
          />
        )}
      </main>

      {/* Sticky Mobile-First Navigation Bar */}
      <nav className="bottom-nav">
        <button 
          type="button" 
          className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}
          onClick={() => setActiveTab('dashboard')}
        >
          <Home size={20} />
          <span>{t.tabDashboard}</span>
        </button>

        <button 
          type="button" 
          className={`nav-item ${activeTab === 'ai' ? 'active' : ''}`}
          onClick={() => setActiveTab('ai')}
        >
          <Bot size={20} />
          <span>{t.tabNexAI}</span>
        </button>

        <button 
          type="button" 
          className={`nav-item ${activeTab === 'vision' ? 'active' : ''}`}
          onClick={() => setActiveTab('vision')}
        >
          <Camera size={20} />
          <span>{t.tabCropVision}</span>
        </button>

        <button 
          type="button" 
          className={`nav-item ${activeTab === 'weather' ? 'active' : ''}`}
          onClick={() => setActiveTab('weather')}
        >
          <CloudSun size={20} />
          <span>{t.tabWeather}</span>
        </button>

        <button 
          type="button" 
          className={`nav-item ${activeTab === 'tasks' ? 'active' : ''}`}
          onClick={() => setActiveTab('tasks')}
        >
          <CheckSquare size={20} />
          <span>{t.tabTasks}</span>
        </button>
      </nav>
    </div>
  );

  if (isMobilePreview) {
    return (
      <div className="mobile-preview-canvas">
        <div className="mobile-preview-bar">
          <div className="mobile-preview-bar-left">
            <span className="mobile-preview-badge">📱 Mobile View (390 × 844)</span>
            <span className="mobile-preview-hint">Testing responsive farmer experience</span>
          </div>
          <button
            type="button"
            className="mobile-preview-exit-btn"
            onClick={toggleMobilePreview}
          >
            Exit Mobile View ✕
          </button>
        </div>
        <div className="mobile-device-shell">
          <div className="mobile-device-notch"></div>
          <div className="mobile-device-screen">
            {appContent}
          </div>
        </div>
      </div>
    );
  }

  return appContent;
}
