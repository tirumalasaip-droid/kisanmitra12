import React, { useState } from 'react';
import { TRANSLATIONS } from '../translations';
import { Calculator, TrendingUp, TrendingDown, AlertCircle } from 'lucide-react';

export default function ProfitCalculator({ profile }) {
  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;

  const [harvestQty, setHarvestQty] = useState('25'); // e.g. 25 quintals
  const [sellingPrice, setSellingPrice] = useState('2200'); // ₹ per quintal
  const [seedCost, setSeedCost] = useState('4500');
  const [fertilizerCost, setFertilizerCost] = useState('8000');
  const [laborCost, setLaborCost] = useState('12000');
  const [irrigationCost, setIrrigationCost] = useState('3500');
  const [otherCost, setOtherCost] = useState('2500');

  // Calculations
  const qtyNum = parseFloat(harvestQty) || 0;
  const priceNum = parseFloat(sellingPrice) || 0;
  const revenue = qtyNum * priceNum;

  const expenses = 
    (parseFloat(seedCost) || 0) +
    (parseFloat(fertilizerCost) || 0) +
    (parseFloat(laborCost) || 0) +
    (parseFloat(irrigationCost) || 0) +
    (parseFloat(otherCost) || 0);

  const netResult = revenue - expenses;
  const isProfitable = netResult >= 0;

  return (
    <div className="calc-container">
      <div className="calc-header">
        <div className="calc-title-group">
          <Calculator size={26} color="#16a34a" />
          <div>
            <h2 className="title-text">{t.calcTitle}</h2>
            <p className="subtitle-text">{t.calcSubtitle}</p>
          </div>
        </div>
      </div>

      {/* Honesty & Disclaimer Banner */}
      <div className="calc-disclaimer-box">
        <AlertCircle size={18} color="#b45309" />
        <p>{t.calcDisclaimer}</p>
      </div>

      <div className="calc-content-grid">
        {/* Left / Top: Input fields */}
        <div className="calc-inputs-card">
          <h3 className="card-section-heading">
            {profile.language === 'te' ? 'దిగుబడి & అమ్మకపు వివరాలు' : profile.language === 'hi' ? 'उपज और बिक्री विवरण' : 'Yield & Sales Estimation'}
          </h3>

          <div className="calc-field">
            <label>{t.harvestQty}</label>
            <input
              type="number"
              className="calc-input"
              value={harvestQty}
              onChange={(e) => setHarvestQty(e.target.value)}
              placeholder="0"
            />
          </div>

          <div className="calc-field">
            <label>{t.sellingPrice}</label>
            <input
              type="number"
              className="calc-input"
              value={sellingPrice}
              onChange={(e) => setSellingPrice(e.target.value)}
              placeholder="0"
            />
          </div>

          <h3 className="card-section-heading" style={{ marginTop: '20px' }}>
            {profile.language === 'te' ? 'సాగు ఖర్చులు (రూపాయల్లో)' : profile.language === 'hi' ? 'कृषि लागत (रुपये में)' : 'Cultivation Costs (₹)'}
          </h3>

          <div className="calc-field">
            <label>{t.seedCost}</label>
            <input
              type="number"
              className="calc-input"
              value={seedCost}
              onChange={(e) => setSeedCost(e.target.value)}
              placeholder="0"
            />
          </div>

          <div className="calc-field">
            <label>{t.fertilizerCost}</label>
            <input
              type="number"
              className="calc-input"
              value={fertilizerCost}
              onChange={(e) => setFertilizerCost(e.target.value)}
              placeholder="0"
            />
          </div>

          <div className="calc-field">
            <label>{t.laborCost}</label>
            <input
              type="number"
              className="calc-input"
              value={laborCost}
              onChange={(e) => setLaborCost(e.target.value)}
              placeholder="0"
            />
          </div>

          <div className="calc-field">
            <label>{t.irrigationCost}</label>
            <input
              type="number"
              className="calc-input"
              value={irrigationCost}
              onChange={(e) => setIrrigationCost(e.target.value)}
              placeholder="0"
            />
          </div>

          <div className="calc-field">
            <label>{t.otherCost}</label>
            <input
              type="number"
              className="calc-input"
              value={otherCost}
              onChange={(e) => setOtherCost(e.target.value)}
              placeholder="0"
            />
          </div>
        </div>

        {/* Right / Bottom: Financial Summary Result */}
        <div className="calc-summary-card">
          <h3 className="summary-title">{t.calcResults}</h3>

          <div className="summary-metric-row">
            <span className="summary-lbl">{t.totalRevenue}</span>
            <span className="summary-val">₹{revenue.toLocaleString('en-IN')}</span>
          </div>

          <div className="summary-metric-row">
            <span className="summary-lbl">{t.totalExpenses}</span>
            <span className="summary-val text-muted">₹{expenses.toLocaleString('en-IN')}</span>
          </div>

          <div className="summary-divider" />

          <div className={`summary-result-box ${isProfitable ? 'profit-box' : 'loss-box'}`}>
            <div className="result-icon-wrap">
              {isProfitable ? (
                <TrendingUp size={28} color="#15803d" />
              ) : (
                <TrendingDown size={28} color="#dc2626" />
              )}
            </div>
            <div>
              <span className="result-tag">{isProfitable ? t.netProfit : t.netLoss}</span>
              <div className="result-amount">₹{Math.abs(netResult).toLocaleString('en-IN')}</div>
            </div>
          </div>

          <div className="summary-help-text">
            <span>
              {profile.language === 'te'
                ? `లెక్కించిన ప్రకారం, ప్రతి క్వింటాలుకు మీ సగటు సాగు ఖర్చు ₹${qtyNum > 0 ? (expenses / qtyNum).toFixed(0) : 0}.`
                : profile.language === 'hi'
                ? `गणना के अनुसार, प्रति क्विंटल औसत उत्पादन लागत ₹${qtyNum > 0 ? (expenses / qtyNum).toFixed(0) : 0} है।`
                : `Calculated average production cost per unit is ₹${qtyNum > 0 ? (expenses / qtyNum).toFixed(0) : 0}.`}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
