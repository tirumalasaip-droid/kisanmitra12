require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { GoogleGenAI } = require('@google/genai');

const app = express();
const PORT = process.env.PORT || 5000;

// Enable JSON parser with large payload limit for image uploads
app.use(express.json({ limit: '20mb' }));
app.use(cors());

// Initialize Google Gemini SDK if API key is provided
let aiClient = null;
const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;

if (apiKey && apiKey.trim() !== '') {
  try {
    aiClient = new GoogleGenAI({ apiKey: apiKey.trim() });
    console.log('[AgriNex Backend] Google Gemini AI Client initialized successfully.');
  } catch (err) {
    console.error('[AgriNex Backend] Failed to initialize GoogleGenAI client:', err.message);
  }
} else {
  console.log('[AgriNex Backend] No GEMINI_API_KEY found in environment. Running in unconfigured AI mode.');
}

// Health check / AI status endpoint
app.get('/api/status', (req, res) => {
  res.json({
    status: 'online',
    appName: 'KisanMitra',
    aiConfigured: Boolean(aiClient),
    message: aiClient
      ? 'Sakhi AI service is fully configured and ready.'
      : 'GEMINI_API_KEY is not configured in .env. Real AI queries and image vision analysis require a Gemini API key from https://aistudio.google.com/.'
  });
});

// Helper to build prompt system context
function buildSystemInstruction(language, farmerName, crop, stage, locationName) {
  const langName = language === 'te' ? 'Telugu (తెలుగు)' : language === 'hi' ? 'Hindi (हिन्दी)' : 'Indian English';

  return `You are "Sakhi", the friendly and expert smart farming companion of KisanMitra built specifically for Indian farmers.
Target Audience: Indian farmers who may have limited technical knowledge.
Farmer Profile:
- Farmer Name: ${farmerName || 'Farmer'}
- Selected Crop: ${crop || 'Not specified'}
- Crop Stage: ${stage || 'Not specified'}
- Farm Location: ${locationName || 'India'}

Language & Communication Rules:
1. Respond EXCLUSIVELY in ${langName}. If Telugu, use natural, proper Telugu script (తెలుగు లిపి). If Hindi, use natural Devanagari Hindi script (हिन्दी). If English, use simple Indian English.
2. Address the farmer respectfully by their name (e.g. in Telugu: "${farmerName ? farmerName + ' గారు' : 'రైతు గారు'}", in Hindi: "${farmerName ? farmerName + ' जी' : 'किसान भाई'}").
3. Explain recommendations in simple, clear, actionable steps that a farmer can easily follow in the field.
4. Avoid unsupported claims, guaranteed yields, fabricated crop prices, or unsafe pesticide advice.
5. Do NOT invent pesticide dosages or recommend dangerous chemical combinations.
6. Clearly state uncertainty when information is insufficient and ask relevant clarifying questions.
7. Maintain conversational context across follow-up queries.
8. Do NOT append repetitive disclaimers or boilerplate advice to consult agricultural officers or Krishi Vigyan Kendra (KVK); provide direct, helpful answers to the farmer's question.`;
}

// Nex AI Chat Endpoint
app.post('/api/ai/chat', async (req, res) => {
  const { message, history = [], language = 'en', farmerName, crop, stage, locationName, weatherContext } = req.body;

  if (!aiClient) {
    return res.status(503).json({
      error: 'AI_NOT_CONFIGURED',
      message: 'GEMINI_API_KEY is not configured in backend/.env. Please provide a valid Gemini API key from https://aistudio.google.com/ to enable live Nex AI conversations.'
    });
  }

  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty' });
  }

  try {
    const systemPrompt = buildSystemInstruction(language, farmerName, crop, stage, locationName);
    
    // Construct prompt payload including history
    let contents = [];
    
    // System instruction passed in request or prepended
    let promptIntro = `${systemPrompt}\n\n`;
    if (weatherContext) {
      promptIntro += `Current Farm Weather Context: ${JSON.stringify(weatherContext)}\n\n`;
    }

    // Format previous messages
    if (Array.isArray(history) && history.length > 0) {
      // Limit to last 8 turns for efficiency and low token usage
      const recentHistory = history.slice(-8);
      for (const item of recentHistory) {
        if (item.sender === 'user') {
          contents.push({ role: 'user', parts: [{ text: item.text }] });
        } else if (item.sender === 'bot') {
          contents.push({ role: 'model', parts: [{ text: item.text }] });
        }
      }
    }

    // Current turn
    const userTurn = contents.length === 0 
      ? `${promptIntro}Farmer's Query: ${message}` 
      : message;

    contents.push({ role: 'user', parts: [{ text: userTurn }] });

    // Call Gemini 3.5 flash-lite
    const response = await aiClient.models.generateContent({
      model: 'gemini-3.5-flash-lite',
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.3,
        maxOutputTokens: 1000
      }
    });

    const replyText = response.text;
    res.json({ reply: replyText });
  } catch (err) {
    console.error('[AgriNex Backend] AI Chat Error:', err);
    res.status(500).json({
      error: 'AI_PROCESSING_ERROR',
      message: 'Error communicating with AI service: ' + (err.message || 'Unknown error')
    });
  }
});

// Clean markdown symbols (#, *, _, `, ~, >, bullets, URLs) for spoken audio
function sanitizeTextForSpeech(rawText) {
  if (!rawText) return '';
  return rawText
    // Remove code blocks and inline code
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]+)`/g, '$1')
    // Remove markdown links [text](url) -> text
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    // Remove headers (# Header)
    .replace(/^\s{0,3}#{1,6}\s+/gm, '')
    // Remove bullet points and numbered list markers (*, -, +, 1.)
    .replace(/^\s*[\*\-\+]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    // Remove markdown emphasis formatting (**bold**, *italic*, __bold__, _italic_, ~~strike~~)
    .replace(/(\*\*|__)(.*?)\1/g, '$2')
    .replace(/(\*|_)(.*?)\1/g, '$2')
    .replace(/~~(.*?)~~/g, '$1')
    // Remove blockquotes and horizontal rules
    .replace(/^\s*>\s+/gm, '')
    .replace(/^\s*[-*_]{3,}\s*$/gm, '')
    // Remove remaining stray markdown or punctuation artifacts
    .replace(/[#*_~`]/g, '')
    // Collapse excess whitespace and linebreaks
    .replace(/\s+/g, ' ')
    .trim();
}

// Split text into natural sentence/clause chunks under 180 chars for TTS engines
function splitIntoTTSChunks(text, maxChunkLen = 170) {
  if (!text) return [];
  // Split along sentence endings (period, question mark, exclamation, newline, or Telugu full-stop / comma)
  const segments = text.match(/[^.!?\n,;]+[.!?\n,;]?/g) || [text];
  const chunks = [];
  let current = '';

  for (const seg of segments) {
    const trimmed = seg.trim();
    if (!trimmed) continue;

    if ((current + ' ' + trimmed).trim().length <= maxChunkLen) {
      current = (current ? current + ' ' : '') + trimmed;
    } else {
      if (current) chunks.push(current);
      if (trimmed.length > maxChunkLen) {
        // If an individual clause is extraordinarily long, split by words
        const words = trimmed.split(' ');
        let wordChunk = '';
        for (const w of words) {
          if ((wordChunk + ' ' + w).trim().length <= maxChunkLen) {
            wordChunk = (wordChunk ? wordChunk + ' ' : '') + w;
          } else {
            if (wordChunk) chunks.push(wordChunk);
            wordChunk = w;
          }
        }
        current = wordChunk;
      } else {
        current = trimmed;
      }
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

// Reliable TTS proxy endpoint for Telugu (and other languages) when browser lacks local voice
app.get('/api/tts', async (req, res) => {
  const { text, lang = 'te' } = req.query;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Text parameter is required' });
  }

  try {
    const cleanText = sanitizeTextForSpeech(text);
    if (!cleanText) {
      return res.status(400).json({ error: 'No speakable text found' });
    }

    const ttsLang = lang === 'te' ? 'te' : lang === 'hi' ? 'hi' : 'en';
    const chunks = splitIntoTTSChunks(cleanText, 170);

    const https = require('https');
    const fetchTTSChunk = (chunkText) => {
      return new Promise((resolve, reject) => {
        const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(chunkText)}&tl=${ttsLang}&client=tw-ob`;
        const req = https.get(url, {
          headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
          timeout: 8000
        }, (resp) => {
          if (resp.statusCode !== 200) {
            resp.resume();
            return reject(new Error(`Upstream TTS status ${resp.statusCode}`));
          }
          const chunks = [];
          resp.on('data', d => chunks.push(d));
          resp.on('end', () => resolve(Buffer.concat(chunks)));
        });

        req.on('error', reject);
        req.on('timeout', () => {
          req.destroy();
          reject(new Error('TTS request timeout'));
        });
      });
    };

    const audioBuffers = [];
    for (const chunk of chunks) {
      if (!chunk.trim()) continue;
      try {
        const buf = await fetchTTSChunk(chunk);
        if (buf && buf.length > 0) {
          audioBuffers.push(buf);
        }
      } catch (chunkErr) {
        console.warn('[AgriNex Backend] Warning on TTS chunk:', chunk.slice(0, 30), chunkErr.message);
      }
    }

    if (audioBuffers.length === 0) {
      throw new Error('No audio buffers could be generated');
    }

    const fullAudio = Buffer.concat(audioBuffers);

    res.set({
      'Content-Type': 'audio/mpeg',
      'Content-Length': fullAudio.length,
      'Cache-Control': 'public, max-age=86400'
    });

    res.send(fullAudio);
  } catch (err) {
    console.error('[AgriNex Backend] TTS Error:', err.message);
    res.status(500).json({ error: 'TTS_GENERATION_FAILED', message: err.message });
  }
});

// Nex AI Crop Photo Vision Analysis Endpoint
app.post('/api/ai/analyze-crop', async (req, res) => {
  const { imageBase64, mimeType = 'image/jpeg', language = 'en', farmerName, crop, stage, locationName } = req.body;

  if (!aiClient) {
    return res.status(503).json({
      error: 'AI_VISION_NOT_CONFIGURED',
      message: 'GEMINI_API_KEY is not configured in backend/.env. An AI vision service must be configured before crop photo diagnosis can work.'
    });
  }

  if (!imageBase64) {
    return res.status(400).json({ error: 'Image data is required' });
  }

  try {
    const langName = language === 'te' ? 'Telugu (తెలుగు)' : language === 'hi' ? 'Hindi (हिन्दी)' : 'Indian English';
    
    // Strict prompt according to requirement 8
    const visionInstruction = `You are Nex AI, the agricultural vision specialist for AgriNex.
The farmer has uploaded a photo of their plant/crop for diagnosis.
Farmer Details:
- Name: ${farmerName || 'Farmer'}
- Selected Crop: ${crop || 'Not specified'}
- Crop Stage: ${stage || 'Not specified'}
- Location: ${locationName || 'India'}

Language Instruction:
Provide your entire analysis response in ${langName}. If Telugu, use natural Telugu script. If Hindi, use natural Hindi Devanagari script. If English, use simple clear Indian English.

STRICT DIAGNOSTIC PROTOCOL:
1. Visible Symptoms: Describe exactly what visual symptoms are visible in the photo (e.g., leaf discoloration, spots, wilting, holes, curling, mold).
2. Possible Causes: Suggest possible disease, pest, nutrient deficiency, or environmental causes based strictly on the visible evidence.
3. Visual Evidence: Explain what visual clues support each possibility.
4. Uncertainty & Safety: State clearly that this is an AI photo-based screening and NOT a confirmed laboratory diagnosis.
5. Follow-up Questions: Ask 2-3 essential questions to narrow down the issue (e.g., when did it start, is it spreading to other plants, recent rain/irrigation, fertilizer applied).
6. Practical Low-Risk First Steps: Give immediate, safe, low-risk cultural practices (e.g., isolate infected leaves, check soil moisture, avoid overhead watering, ensure drainage).
7. Chemical/Pesticide Warning: DO NOT invent pesticide dosages or recommend dangerous toxic chemicals.
8. Next Steps: Focus on practical cultural practices and clear next steps without adding repetitive boilerplate endings.`;

    // Clean base64 string if it contains data URI prefix
    const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.5-flash-lite',
      contents: [
        {
          role: 'user',
          parts: [
            { text: visionInstruction },
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType
              }
            }
          ]
        }
      ],
      config: {
        temperature: 0.2,
        maxOutputTokens: 1200
      }
    });

    const analysisText = response.text;
    res.json({ analysis: analysisText });
  } catch (err) {
    console.error('[AgriNex Backend] Vision Analysis Error:', err);
    res.status(500).json({
      error: 'VISION_PROCESSING_ERROR',
      message: 'Failed to analyze crop photo with AI vision: ' + (err.message || 'Unknown error')
    });
  }
});

// Serve static production build from client/dist if present
const path = require('path');
const clientDistPath = path.join(__dirname, 'client', 'dist');
app.use(express.static(clientDistPath));

app.use((req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(clientDistPath, 'index.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`[AgriNex Backend] Server running on http://localhost:${PORT}`);
});
