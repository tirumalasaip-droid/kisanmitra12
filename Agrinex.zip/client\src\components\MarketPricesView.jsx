import React, { useState, useEffect } from 'react';
import { TRANSLATIONS } from '../translations';
import { ShoppingBag, Plus, Tag, Store, Calendar, AlertCircle } from 'lucide-react';

export default function MarketPricesView({ profile }) {
  const t = TRANSLATIONS[profile.language] || TRANSLATIONS.en;

  // Stored price records with clear source attribution
  const [rates, setRates] = useState(() => {
    const saved = localStorage.getItem('agrinex_market_rates');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return [
      {
        id: '1',
        crop: profile.language === 'te' ? 'వరి (Paddy)' : 'Paddy (Common)',
        market: 'Guntur APMC Mandi',
        price: '2320',
        date: '2026-10-14',
        source: 'AGMARKNET Standard Benchmark / Verified Mandi Bulletin'
      },
      {
        id: '2',
        crop: profile.language === 'te' ? 'పత్తి (Cotton)' : 'Cotton (Medium Staple)',
        market: 'Warangal / Adilabad Mandi',
        price: '7150',
        date: '2026-10-14',
        source: 'Cotton Corporation of India (CCI) / APMC Yard'
      },
      {
        id: '3',
        crop: profile.language === 'te' ? 'మిరప (Dry Chilli)' : 'Chilli (Teja / Wonder Hot)',
        market: 'Guntur Mirchi Yard',
        price: '18500',
        date: '2026-10-14',
        source: 'Spices Board & Guntur Yard Daily Record'
      }
    ];
  });

  const [cropInput, setCropInput] = useState('');
  const [marketInput, setMarketInput] = useState('');
  const [priceInput, setPriceInput] = useState('');

  useEffect(() => {
    localStorage.setItem('agrinex_market_rates', JSON.stringify(rates));
  }, [rates]);

  const handleAddRate = (e) => {
    e.preventDefault();
    if (!cropInput.trim() || !priceInput.trim()) return;

    const newRate = {
      id: Date.now().toString(),
      crop: cropInput.trim(),
      market: marketInput.trim() || 'Local Market',
      price: priceInput.trim(),
      date: new Date().toISOString().split('T')[0],
      source: 'Farmer Recorded Local Rate'
    };

    setRates([newRate, ...rates]);
    setCropInput('');
    setMarketInput('');
    setPriceInput('');
  };

  return (
    <div className="market-container">
      <div className="market-header">
        <div className="market-title-group">
          <ShoppingBag size={26} color="#16a34a" />
          <div>
            <h2 className="title-text">{t.marketTitle}</h2>
            <p className="subtitle-text">{t.marketSubtitle}</p>
          </div>
        </div>
      </div>

      {/* Honest source disclaimer */}
      <div className="market-disclaimer-box">
        <AlertCircle size={20} color="#0369a1" />
        <p>{t.marketNotice}</p>
      </div>

      {/* Manual Price Entry Form */}
      <form onSubmit={handleAddRate} className="add-price-card">
        <h3 className="form-subtitle">
          {profile.language === 'te' ? 'స్థానిక మండి రేటును నమోదు చేయండి' : profile.language === 'hi' ? 'स्थानीय मंडी भाव दर्ज करें' : 'Record Local Mandi Rate'}
        </h3>
        <div className="price-inputs-grid">
          <input
            type="text"
            className="market-input"
            value={cropInput}
            onChange={(e) => setCropInput(e.target.value)}
            placeholder={t.cropNameLabel}
          />
          <input
            type="text"
            className="market-input"
            value={marketInput}
            onChange={(e) => setMarketInput(e.target.value)}
            placeholder={t.marketNameLabel}
          />
          <input
            type="number"
            className="market-input"
            value={priceInput}
            onChange={(e) => setPriceInput(e.target.value)}
            placeholder={t.modalPriceLabel}
          />
        </div>
        <button type="submit" className="btn-primary" style={{ marginTop: '10px' }} disabled={!cropInput.trim() || !priceInput.trim()}>
          <Plus size={18} />
          <span>{t.addCustomPrice}</span>
        </button>
      </form>

      {/* Price Cards List */}
      <div className="market-list">
        {rates.map(item => (
          <div key={item.id} className="rate-card">
            <div className="rate-left">
              <span className="crop-title">{item.crop}</span>
              <span className="market-yard">📍 {item.market}</span>
              <span className="rate-source">ℹ️ Source: {item.source} • As of {item.date}</span>
            </div>
            <div className="rate-right">
              <span className="price-badge">₹{item.price}</span>
              <span className="unit-label">/ quintal</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
